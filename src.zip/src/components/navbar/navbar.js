var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { MenuController } from 'ionic-angular';
var NavbarPage = (function () {
    function NavbarPage(menuCtrl) {
        this.menuCtrl = menuCtrl;
    }
    Object.defineProperty(NavbarPage.prototype, "menu", {
        get: function () {
            return this._menu;
        },
        set: function (value) {
            this._menu = value;
            this.menuCtrl.enable(this._menu);
        },
        enumerable: true,
        configurable: true
    });
    NavbarPage.prototype.ionViewDidLoad = function () {
        //
    };
    __decorate([
        Input('menu'),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], NavbarPage.prototype, "menu", null);
    NavbarPage = __decorate([
        Component({
            selector: 'page-navbar',
            templateUrl: 'navbar.html',
        }),
        __metadata("design:paramtypes", [MenuController])
    ], NavbarPage);
    return NavbarPage;
}());
export { NavbarPage };
//# sourceMappingURL=navbar.js.map