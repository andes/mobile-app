var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Output, EventEmitter } from '@angular/core';
var AdsAccordionPage = (function () {
    function AdsAccordionPage() {
        this.onToogle = new EventEmitter();
        this.prevent = true;
        this.isOpen = false;
    }
    AdsAccordionPage.prototype.ngOnInit = function () {
    };
    AdsAccordionPage.prototype.toogle = function (state) {
        this.isOpen = state;
    };
    AdsAccordionPage.prototype.onHeaderClick = function () {
        if (this.prevent) {
            this.isOpen = !this.isOpen;
        }
        this.onToogle.emit(this.isOpen);
    };
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], AdsAccordionPage.prototype, "onToogle", void 0);
    AdsAccordionPage = __decorate([
        Component({
            selector: 'ads-accordion',
            template: "<div class=\"ads-accordion\" [ngClass]=\"{'open': isOpen}\">\n            <div class=\"ads-accordion-header\" (click)=\"onHeaderClick(item)\">\n                <div class=\"ads-header-container\">\n                <h2>\n                    <ng-content select=\"[header]\"></ng-content>\n                </h2>\n                <h4>\n                    <ng-content select=\"[subtitulo]\"></ng-content>\n                </h4>\n                </div>\n                <ion-icon class=\"outline\" name=\"ios-arrow-down-outline\"></ion-icon>\n            </div>\n            <div class=\"ads-accordion-content\">\n                <ng-content select=\"[content]\"></ng-content>\n            </div>\n        </div>"
        }),
        __metadata("design:paramtypes", [])
    ], AdsAccordionPage);
    return AdsAccordionPage;
}());
export { AdsAccordionPage };
//# sourceMappingURL=ads-accordion.js.map