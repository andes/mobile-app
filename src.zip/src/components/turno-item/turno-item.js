var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavController, AlertController, PopoverController } from 'ionic-angular';
import * as moment from 'moment/moment';
// providers
import { TurnosProvider } from '../../providers/turnos';
import { ToastProvider } from '../../providers/toast';
// pages
import { DropdownTurnoItem } from './dropdown-turno-item';
var TurnoItemComponent = (function () {
    function TurnoItemComponent(toast, popoverCtrl, turnosProvider, alertCtrl, navCtrl) {
        this.toast = toast;
        this.popoverCtrl = popoverCtrl;
        this.turnosProvider = turnosProvider;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.onCancelEvent = new EventEmitter();
        this.onClickEvent = new EventEmitter();
        this.expand = false;
        //
    }
    TurnoItemComponent.prototype.ngOnInit = function () {
        moment.locale('es');
        if (this.turno.reasignado_anterior) {
            this.turno.reasignado_anterior.fecha = moment(this.turno.reasignado_anterior.horaInicio);
        }
    };
    TurnoItemComponent.prototype.profesionalName = function () {
        if (this.turno.profesionales.length > 0) {
            return this.turno.profesionales[0].apellido + ' ' + this.turno.profesionales[0].nombre;
        }
        else {
            return 'Sin profesional';
        }
    };
    TurnoItemComponent.prototype.turnoFecha = function () {
        return moment(this.turno.horaInicio).format('DD [de] MMMM');
    };
    TurnoItemComponent.prototype.turnoHora = function () {
        return moment(this.turno.horaInicio).format('HH:mm');
    };
    TurnoItemComponent.prototype.turnoConfirmado = function () {
        if (this.turno.confirmedAt != null) {
            return 'Confirmado';
        }
    };
    TurnoItemComponent.prototype.tootleExpand = function () {
        this.expand = !this.expand;
    };
    TurnoItemComponent.prototype.isToday = function () {
        return moment(new Date()).format('DD/MM/YYYY') === moment(this.turno.horaInicio).format('DD/MM/YYYY');
    };
    TurnoItemComponent.prototype.isSuspendido = function () {
        return this.turno.estado === 'suspendido' || this.turno.agenda_estado === 'suspendida';
    };
    TurnoItemComponent.prototype.isReasignado = function () {
        return this.turno.reasignado;
    };
    TurnoItemComponent.prototype.turnoConfirmadoAsistencia = function () {
        return this.turno.asistencia && this.turno.asistencia === 'asistio';
    };
    TurnoItemComponent.prototype.onCancel = function ($event) {
        var _this = this;
        // $event.stopPropagation();
        this.showConfirm('¿Desea cancelar el turno selecionado?', '').then(function () {
            var params = {
                turno_id: _this.turno._id,
                agenda_id: _this.turno.agenda_id,
                bloque_id: _this.turno.bloque_id
            };
            _this.turnosProvider.cancelarTurno(params).then(function () {
                _this.onCancelEvent.emit(_this.turno);
            });
        }).catch(function () { });
    };
    TurnoItemComponent.prototype.onTurnoClick = function () {
        this.onClickEvent.emit(this.turno);
    };
    TurnoItemComponent.prototype.onConfirm = function () {
        var _this = this;
        var params = {
            turno_id: this.turno._id,
            agenda_id: this.turno.agenda_id,
            bloque_id: this.turno.bloque_id
        };
        this.turnosProvider.confirmarTurno(params).then(function () {
            _this.turno.confirmedAt = new Date();
            _this.toast.success('Turno confirmado con exito!');
        }).catch(function () {
            _this.toast.danger('No se pudo confirmar el turno. Vuelva a intentar.');
        });
    };
    TurnoItemComponent.prototype.showConfirm = function (title, message) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var confirm = _this.alertCtrl.create({
                title: title,
                message: message,
                buttons: [
                    {
                        text: 'Cancelar',
                        handler: function () {
                            reject();
                        }
                    },
                    {
                        text: 'Aceptar',
                        handler: function () {
                            resolve();
                        }
                    }
                ]
            });
            confirm.present();
        });
    };
    TurnoItemComponent.prototype.onConfirmAsistencia = function () {
        var _this = this;
        var params = {
            turno_id: this.turno._id,
            agenda_id: this.turno.agenda_id,
            bloque_id: this.turno.bloque_id
        };
        this.turnosProvider.confirmarAsistenciaTurno(params).then(function () {
            _this.turno.asistencia = 'asistio';
            _this.toast.success('Asistencia al turno confirmada con exito!');
        }).catch(function () {
            _this.toast.danger('No se pudo confirmar la asistencia del turno. Vuelva a intentar.');
        });
    };
    TurnoItemComponent.prototype.showConfirmAsistencia = function (title, message) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var confirm = _this.alertCtrl.create({
                title: title,
                message: message,
                buttons: [
                    {
                        text: 'Cancelar',
                        handler: function () {
                            reject();
                        }
                    },
                    {
                        text: 'Aceptar',
                        handler: function () {
                            resolve();
                        }
                    }
                ]
            });
            confirm.present();
        });
    };
    TurnoItemComponent.prototype.onMenuItemClick = function (action) {
        if (action === 'cancelar') {
            this.onCancel(null);
        }
        else if (action === 'confirmar') {
            this.onConfirm();
        }
        else if (action === 'asistencia') {
            this.onConfirmAsistencia();
        }
    };
    TurnoItemComponent.prototype.onMenuClick = function ($event) {
        $event.stopPropagation();
        var self = this;
        var data = {
            callback: function (action) {
                self.onMenuItemClick(action);
            },
            showConfirm: !this.turno.confirmedAt,
            showConfirmAsistencia: !this.turno.asistencia
        };
        var popover = this.popoverCtrl.create(DropdownTurnoItem, data);
        popover.present({
            ev: $event
        });
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], TurnoItemComponent.prototype, "turno", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], TurnoItemComponent.prototype, "onCancelEvent", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], TurnoItemComponent.prototype, "onClickEvent", void 0);
    TurnoItemComponent = __decorate([
        Component({
            selector: 'turno-item',
            templateUrl: 'turno-item.html',
        }),
        __metadata("design:paramtypes", [ToastProvider,
            PopoverController,
            TurnosProvider,
            AlertController,
            NavController])
    ], TurnoItemComponent);
    return TurnoItemComponent;
}());
export { TurnoItemComponent };
//# sourceMappingURL=turno-item.js.map