var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavParams, ViewController } from 'ionic-angular';
var DropdownTurnoItem = (function () {
    function DropdownTurnoItem(viewCtrl, params) {
        this.viewCtrl = viewCtrl;
        this.params = params;
        this.callback = this.params.get('callback');
        this.showConfirm = this.params.get('showConfirm');
        this.showConfirmAsistencia = this.params.get('showConfirmAsistencia');
    }
    DropdownTurnoItem.prototype.close = function (action) {
        this.viewCtrl.dismiss();
        this.callback(action);
    };
    DropdownTurnoItem = __decorate([
        Component({
            template: "\n    <ion-list class=\"turno-item-popover\">\n      <!--<ion-list-header>Menu</ion-list-header>-->\n      <button ion-item (click)=\"close('asistencia')\" *ngIf=\"showConfirmAsistencia\" class=\"asistencia-item\"> <ion-icon name=\"checkmark\"></ion-icon> Dar asistencia a turno </button>\n      <button ion-item (click)=\"close('confirmar')\" *ngIf=\"showConfirm\" class=\"confirmar-item\"> <ion-icon name=\"checkmark\"></ion-icon> Confirmar turno </button>\n      <button ion-item (click)=\"close('cancelar')\" class=\"cancelar-item\"> <ion-icon name=\"remove-circle\"> </ion-icon> Cancelar turno </button>\n    </ion-list>\n  "
        }),
        __metadata("design:paramtypes", [ViewController, NavParams])
    ], DropdownTurnoItem);
    return DropdownTurnoItem;
}());
export { DropdownTurnoItem };
//# sourceMappingURL=dropdown-turno-item.js.map