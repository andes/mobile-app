var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavController, AlertController, PopoverController } from 'ionic-angular';
import * as moment from 'moment/moment';
import { ToastProvider } from '../../providers/toast';
import { AuthProvider } from '../../providers/auth/auth';
import { AgendasProvider } from '../../providers/agendas';
import { DropdownAgendaItem } from './dropdown-agenda-item';
var AgendaItemComponent = (function () {
    function AgendaItemComponent(popoverCtrl, alertCtrl, navCtrl, authProvider, agendasProvider, toast) {
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.authProvider = authProvider;
        this.agendasProvider = agendasProvider;
        this.toast = toast;
        this.onCancelEvent = new EventEmitter();
        //
    }
    AgendaItemComponent.prototype.ngOnInit = function () {
        moment.locale('es');
    };
    AgendaItemComponent.prototype.fecha = function () {
        return moment(this.agenda.horaInicio).format('DD [de] MMMM');
    };
    AgendaItemComponent.prototype.hora = function () {
        return moment(this.agenda.horaInicio).format('HH:mm');
    };
    AgendaItemComponent.prototype.hayAviso = function () {
        var _this = this;
        return this.agenda.avisos && this.agenda.avisos.findIndex(function (item) { return item.profesionalId === _this.authProvider.user.profesionalId; }) >= 0;
    };
    AgendaItemComponent.prototype.avisoEstado = function () {
        var _this = this;
        if (this.agenda.avisos) {
            var aviso = this.agenda.avisos.find(function (item) { return item.profesionalId === _this.authProvider.user.profesionalId; });
            if (aviso) {
                return aviso.estado;
            }
        }
        return null;
    };
    AgendaItemComponent.prototype.isToday = function () {
        return moment(new Date()).format('DD/MM/YYYY') === moment(this.agenda.horaInicio).format('DD/MM/YYYY');
    };
    AgendaItemComponent.prototype.onCancel = function () {
        var _this = this;
        this.showConfirm('¿Desea informar la suspensión de la agenda?', '').then(function () {
            var params = {
                op: 'avisos',
                estado: 'suspende',
                profesionalId: _this.authProvider.user.profesionalId,
            };
            _this.agendasProvider.patch(_this.agenda.id, params).then(function (data) {
                _this.agenda.avisos = data.avisos;
                _this.toast.success('SU AGENDA FUE SUSPENDIDA');
            }).catch(function () {
                _this.toast.danger('VUELVALO A INTENTAR');
            });
        }).catch(function () { });
    };
    AgendaItemComponent.prototype.onConfirm = function () {
        var _this = this;
        var params = {
            op: 'avisos',
            estado: 'confirma',
            profesionalId: this.authProvider.user.profesionalId,
        };
        this.agendasProvider.patch(this.agenda.id, params).then(function (data) {
            _this.agenda.avisos = data.avisos;
            _this.toast.success('SU AGENDA FUE CONFIRMADA');
        }).catch(function () {
            _this.toast.danger('VUELVALO A INTENTAR');
        });
    };
    AgendaItemComponent.prototype.showConfirm = function (title, message) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var confirm = _this.alertCtrl.create({
                title: title,
                message: message,
                buttons: [
                    {
                        text: 'Cancelar',
                        handler: function () {
                            reject();
                        }
                    },
                    {
                        text: 'Aceptar',
                        handler: function () {
                            resolve();
                        }
                    }
                ]
            });
            confirm.present();
        });
    };
    AgendaItemComponent.prototype.onMenuItemClick = function (action) {
        if (action === 'cancelar') {
            this.onCancel();
        }
        else if (action === 'confirmar') {
            this.onConfirm();
        }
    };
    AgendaItemComponent.prototype.onMenuClick = function ($event) {
        $event.stopPropagation();
        var self = this;
        var data = {
            callback: function (action) {
                self.onMenuItemClick(action);
            }
        };
        var popover = this.popoverCtrl.create(DropdownAgendaItem, data);
        popover.present({
            ev: $event
        });
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], AgendaItemComponent.prototype, "agenda", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], AgendaItemComponent.prototype, "onCancelEvent", void 0);
    AgendaItemComponent = __decorate([
        Component({
            selector: 'agenda-item',
            templateUrl: 'agenda-item.html',
        }),
        __metadata("design:paramtypes", [PopoverController,
            AlertController,
            NavController,
            AuthProvider,
            AgendasProvider,
            ToastProvider])
    ], AgendaItemComponent);
    return AgendaItemComponent;
}());
export { AgendaItemComponent };
//# sourceMappingURL=agenda-item.js.map