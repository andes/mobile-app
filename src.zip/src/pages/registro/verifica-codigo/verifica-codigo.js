var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FormBuilder, Validators } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { AlertController } from 'ionic-angular';
// pages
import { RegistroUserDataPage } from '../user-data/user-data';
// providers
import { AuthProvider } from '../../../providers/auth/auth';
import { ToastProvider } from '../../../providers/toast';
import { DeviceProvider } from '../../../providers/auth/device';
var VerificaCodigoPage = (function () {
    function VerificaCodigoPage(toastProvider, alertCtrl, storage, authService, navCtrl, navParams, formBuilder, deviceProvider) {
        this.toastProvider = toastProvider;
        this.alertCtrl = alertCtrl;
        this.storage = storage;
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.formBuilder = formBuilder;
        this.deviceProvider = deviceProvider;
        this.submit = false;
        this.email = '';
        this.emailRegex = '^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$';
        this.running = false;
        this.formIngresoCodigo = formBuilder.group({
            codigo: ['', Validators.compose([Validators.required, Validators.maxLength(6)])],
            email: ['', Validators.compose([Validators.required, Validators.pattern(this.emailRegex)])],
        });
    }
    VerificaCodigoPage.prototype.codeTostring = function (code) {
        var c = String(code);
        while (c.length < 6) {
            c = '0' + c;
        }
        ;
        return c;
    };
    VerificaCodigoPage.prototype.onSubmit = function (_a) {
        var _this = this;
        var value = _a.value, valid = _a.valid;
        this.running = true;
        this.authService.checkCode(value.email, value.codigo).then(function () {
            _this.running = false;
            _this.navCtrl.push(RegistroUserDataPage, { email: value.email, code: _this.codeTostring(value.codigo) });
        }).catch(function (err) {
            _this.running = false;
            if (err) {
                _this.toastProvider.danger('DATOS INCORRECTOS');
            }
        });
    };
    VerificaCodigoPage = __decorate([
        Component({
            selector: 'page-verifica-codigo',
            templateUrl: 'verifica-codigo.html',
        }),
        __metadata("design:paramtypes", [ToastProvider,
            AlertController,
            Storage,
            AuthProvider,
            NavController,
            NavParams,
            FormBuilder,
            DeviceProvider])
    ], VerificaCodigoPage);
    return VerificaCodigoPage;
}());
export { VerificaCodigoPage };
//# sourceMappingURL=verifica-codigo.js.map