var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FormBuilder, Validators } from '@angular/forms';
import { Content } from 'ionic-angular';
// Pages
import { HomePage } from '../../home/home';
// Providers
import { AuthProvider } from '../../../providers/auth/auth';
import { ToastProvider } from '../../../providers/toast';
import { PacienteProvider } from '../../../providers/paciente';
var _emailRegex = /^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$/;
var RecuperarPasswordPage = (function () {
    function RecuperarPasswordPage(navCtrl, navParams, authProvider, toast, formBuilder, pacienteProvider) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.authProvider = authProvider;
        this.toast = toast;
        this.formBuilder = formBuilder;
        this.pacienteProvider = pacienteProvider;
        this.displayForm = false;
        this.reset = {};
        this.inProgress = false;
        var emailRegex = '^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$';
        this.formRecuperar = formBuilder.group({
            email: ['', Validators.compose([Validators.required, Validators.pattern(emailRegex)])]
        });
        this.formResetear = formBuilder.group({
            email: ['', Validators.compose([Validators.required, Validators.pattern(emailRegex)])],
            codigo: ['', Validators.compose([Validators.required])],
            password: ['', Validators.compose([Validators.required])],
            password2: ['', Validators.compose([Validators.required])]
        });
    }
    RecuperarPasswordPage.prototype.ionViewDidLoad = function () {
        //
    };
    RecuperarPasswordPage.prototype.sendCode = function () {
        var _this = this;
        if (this.formRecuperar && _emailRegex.test(this.formRecuperar.value.email)) {
            var email_1 = this.formRecuperar.value.email;
            this.inProgress = true;
            this.authProvider.resetPassword(email_1).then(function (result) {
                _this.inProgress = false;
                _this.content.scrollToTop();
                _this.toast.success('EL CODIGO FUE ENVIADO');
                _this.displayForm = true;
                _this.formResetear.patchValue({ email: email_1 });
            }).catch(function (error) {
                _this.inProgress = false;
                if (error) {
                    _this.toast.danger(error.error);
                }
            });
        }
    };
    RecuperarPasswordPage.prototype.yaTengo = function () {
        this.displayForm = true;
        this.content.scrollToTop();
    };
    RecuperarPasswordPage.prototype.resetPassword = function () {
        var _this = this;
        if (this.formResetear && !this.formResetear.invalid) {
            var email = this.formResetear.value.email;
            var codigo = this.formResetear.value.codigo;
            var password = this.formResetear.value.password;
            var password2 = this.formResetear.value.password2;
            if (password !== password2) {
                this.toast.danger('LAS CONTRASEÑAS NO COINCIDEN');
                return;
            }
            this.inProgress = true;
            this.authProvider.restorePassword(email, codigo, password, password2).then(function (data) {
                _this.inProgress = false;
                _this.toast.success('PASSWORD MODIFICADO CORRECTAMENTE');
                _this.navCtrl.setRoot(HomePage);
            }).catch(function (err) {
                _this.inProgress = false;
                if (err) {
                    _this.toast.danger(err.error);
                }
            });
        }
    };
    RecuperarPasswordPage.prototype.cancel = function () {
        this.displayForm = false,
            this.reset = {};
    };
    RecuperarPasswordPage.prototype.onKeyPress = function ($event, tag) {
        if ($event.keyCode === 13) {
            if (tag === 'submit-1') {
                this.sendCode();
            }
            else if (tag === 'submit-2') {
                this.resetPassword();
            }
            else {
                var element = document.getElementById(tag);
                if (element) {
                    element.focus();
                }
            }
        }
    };
    __decorate([
        ViewChild(Content),
        __metadata("design:type", Content)
    ], RecuperarPasswordPage.prototype, "content", void 0);
    RecuperarPasswordPage = __decorate([
        Component({
            selector: 'page-recuperar-password',
            templateUrl: 'recuperar-password.html',
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            AuthProvider,
            ToastProvider,
            FormBuilder,
            PacienteProvider])
    ], RecuperarPasswordPage);
    return RecuperarPasswordPage;
}());
export { RecuperarPasswordPage };
//# sourceMappingURL=recuperar-password.js.map