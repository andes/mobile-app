var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { PasswordValidation } from '../../../validadores/validar-password';
import { Storage } from '@ionic/storage';
// providders
import { ToastProvider } from '../../../providers/toast';
import { AuthProvider } from '../../../providers/auth/auth';
// pages
import { DeviceProvider } from '../../../providers/auth/device';
import { HomePage } from '../../home/home';
var RegistroUserDataPage = (function () {
    function RegistroUserDataPage(toastCtrl, storage, authService, loadingCtrl, navCtrl, navParams, alertCtrl, formBuilder, deviceProvider) {
        this.toastCtrl = toastCtrl;
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.deviceProvider = deviceProvider;
        this.submit = false;
        this.errors = {};
        this.dataMpi = {};
        this.running = false;
        this.email = this.navParams.get('email');
        this.password = this.navParams.get('old_password');
        this.formRegistro = formBuilder.group({
            password: ['', Validators.required],
            confirmarPassword: ['', Validators.required],
        }, {
            validator: PasswordValidation.MatchPassword
        });
    }
    RegistroUserDataPage.prototype.ionViewDidLoad = function () {
        //
    };
    RegistroUserDataPage.prototype.onSubmit = function (_a) {
        var _this = this;
        var value = _a.value, valid = _a.valid;
        this.showLoader();
        this.errors = {};
        this.running = true;
        this.authService.login({
            email: this.email,
            password: this.password,
            new_password: value.password
        }).then(function (result) {
            _this.running = false;
            _this.loading.dismiss();
            _this.deviceProvider.sync();
            _this.navCtrl.setRoot(HomePage);
        }, function (err) {
            _this.running = false;
            _this.loading.dismiss();
            if (err) {
                _this.toastCtrl.danger('HUBO PROBLEMAS EN LA CONEXIÓN');
            }
        });
    };
    RegistroUserDataPage.prototype.showConditions = function () {
        // console.error('not implemented yet!!');
    };
    RegistroUserDataPage.prototype.showLoader = function () {
        this.loading = this.loadingCtrl.create({
            content: 'Registrando...'
        });
        this.loading.present();
    };
    RegistroUserDataPage = __decorate([
        Component({
            selector: 'page-registro-user-data',
            templateUrl: 'user-data.html',
        }),
        __metadata("design:paramtypes", [ToastProvider,
            Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            AlertController,
            FormBuilder,
            DeviceProvider])
    ], RegistroUserDataPage);
    return RegistroUserDataPage;
}());
export { RegistroUserDataPage };
//# sourceMappingURL=user-data.js.map