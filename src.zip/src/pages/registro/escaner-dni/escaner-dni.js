var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { DocumentoEscaneados } from '../regex-documento-scan';
// providers
import { AuthProvider } from '../../../providers/auth/auth';
// pages
import { RegistroPersonalDataPage } from '../personal-data/personal-data';
/**
 * Generated class for the EscanerDniPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
var EscanerDniPage = (function () {
    function EscanerDniPage(storage, authService, barcodeScanner, navCtrl, navParams) {
        this.storage = storage;
        this.authService = authService;
        this.barcodeScanner = barcodeScanner;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.modelo = {};
        this.textoLibre = null;
    }
    EscanerDniPage.prototype.ngOnInit = function () {
    };
    EscanerDniPage.prototype.ionViewDidLoad = function () {
        this.email = this.navParams.get('email');
        this.code = this.navParams.get('code');
    };
    EscanerDniPage.prototype.toDatos = function () {
        this.navCtrl.push(RegistroPersonalDataPage, { email: this.email, code: this.code });
    };
    EscanerDniPage.prototype.comprobarDocumentoEscaneado = function (documento) {
        for (var key in DocumentoEscaneados) {
            if (DocumentoEscaneados[key].regEx.test(documento)) {
                return DocumentoEscaneados[key];
            }
        }
        return null;
    };
    EscanerDniPage.prototype.parseDocumentoEscaneado = function (documento) {
        var datos = this.textoLibre.match(documento.regEx);
        var sexo = '';
        if (documento.grupoSexo > 0) {
            sexo = (datos[documento.grupoSexo].toUpperCase() === 'F') ? 'Femenino' : 'Masculino';
        }
        this.modelo = {
            'nombre': datos[documento.grupoNombre],
            'apellido': datos[documento.grupoApellido],
            'documento': datos[documento.grupoNumeroDocumento].replace(/\D/g, ''),
            'fechaNacimiento': datos[documento.grupoFechaNacimiento],
            'sexo': sexo,
            'genero': sexo,
            'telefono': null
        };
        this.storage.set('barscancode', this.modelo);
        this.navCtrl.push(RegistroPersonalDataPage, { user: this.modelo, email: this.email, code: this.code });
    };
    EscanerDniPage.prototype.scanner = function () {
        var _this = this;
        this.barcodeScanner.scan({
            preferFrontCamera: false,
            formats: 'QR_CODE,PDF_417',
            disableSuccessBeep: false,
            showTorchButton: true,
            torchOn: true,
            prompt: 'Poner el código de barra en la cámara',
            resultDisplayDuration: 500,
        }).then(function (barcodeData) {
            _this.textoLibre = barcodeData.text;
            var documentoEscaneado = _this.comprobarDocumentoEscaneado(_this.textoLibre);
            _this.parseDocumentoEscaneado(documentoEscaneado);
        }, function (err) {
        });
    };
    EscanerDniPage = __decorate([
        Component({
            selector: 'page-escaner-dni',
            templateUrl: 'escaner-dni.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            BarcodeScanner,
            NavController,
            NavParams])
    ], EscanerDniPage);
    return EscanerDniPage;
}());
export { EscanerDniPage };
//# sourceMappingURL=escaner-dni.js.map