var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
// import { DatePicker } from 'ionic2-date-picker/ionic2-date-picker';
import { DatePickerDirective } from 'ion-datepicker';
import { AlertController } from 'ionic-angular';
import * as moment from 'moment';
// pages
import { RegistroUserDataPage } from '../user-data/user-data';
// providers
import { AuthProvider } from '../../../providers/auth/auth';
import { DeviceProvider } from '../../../providers/auth/device';
import { ToastProvider } from '../../../providers/toast';
var RegistroPersonalDataPage = (function () {
    function RegistroPersonalDataPage(storage, authService, loadingCtrl, navCtrl, navParams, alertCtrl, formBuilder, menu, datePicker, deviceProvider, toastCtrl) {
        // this.menu.swipeEnable(false);
        var _this = this;
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.menu = menu;
        this.datePicker = datePicker;
        this.deviceProvider = deviceProvider;
        this.toastCtrl = toastCtrl;
        this.fase = 1;
        this.submit = false;
        this.formRegistro = formBuilder.group({
            nombre: ['', Validators.required],
            apellido: ['', Validators.required],
            documento: ['', Validators.required],
            sexo: ['', Validators.required],
            fechaNacimiento: ['', Validators.required],
        }, {});
        this.formRegistro.patchValue({
            sexo: 'Femenino',
            nacionalidad: 'Argentina'
        });
        this.datePicker.valueChange.subscribe(function (date) {
            _this.formRegistro.patchValue({
                fechaNacimiento: moment(date).format('DD/MM/YYYY')
            });
        });
        this.email = this.navParams.get('email');
        this.code = this.navParams.get('code');
    }
    RegistroPersonalDataPage.prototype.ionViewDidLoad = function () {
        this.datePicker.localeStrings = {
            months: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
            weekdays: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
        };
        this.datePicker.cancelText = 'Cancelar';
    };
    RegistroPersonalDataPage.prototype.ionViewDidEnter = function () {
        var _this = this;
        this.storage.get('barscancode').then(function (value) {
            _this.storage.set('barscancode', null);
            if (value) {
                _this.formRegistro.patchValue(value);
            }
        });
    };
    RegistroPersonalDataPage.prototype.showCalendar = function () {
        this.datePicker.open();
    };
    RegistroPersonalDataPage.prototype.onSubmit = function (_a) {
        var _this = this;
        var value = _a.value, valid = _a.valid;
        value.fechaNacimiento = moment(value.fechaNacimiento, 'DD/MM/YYYY').format('YYYY-MM-DD');
        var data = {
            nombre: value.nombre,
            apellido: value.apellido,
            fechaNacimiento: value.fechaNacimiento,
            sexo: value.sexo.toLowerCase(),
            documento: value.documento
        };
        this.authService.validarAccount(this.email, this.code, data).then(function () {
            _this.navCtrl.push(RegistroUserDataPage, { code: _this.code, email: _this.email, dataMpi: data });
        }).catch(function () {
            _this.toastCtrl.danger('VERIFIQUE SUS DATOS');
        });
    };
    RegistroPersonalDataPage.prototype.onSexoChange = function () {
        var element = document.getElementById('genero');
        if (element) {
            if (element.getElementsByTagName('input').length > 0) {
                element.getElementsByTagName('input')[0].focus();
            }
            else if (element.getElementsByTagName('button').length > 0) {
                element.getElementsByTagName('button')[0].focus();
            }
        }
    };
    RegistroPersonalDataPage.prototype.onKeyPress = function ($event, tag) {
        if ($event.keyCode === 13) {
            if (tag !== 'fecha') {
                var element = document.getElementById(tag);
                if (element) {
                    if (element.getElementsByTagName('input').length > 0) {
                        element.getElementsByTagName('input')[0].focus();
                    }
                    else if (element.getElementsByTagName('button').length > 0) {
                        element.getElementsByTagName('button')[0].focus();
                    }
                }
            }
            else {
                this.showCalendar();
            }
        }
    };
    RegistroPersonalDataPage = __decorate([
        Component({
            selector: 'page-registro-personal-data',
            templateUrl: 'personal-data.html',
            providers: [DatePickerDirective]
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            AlertController,
            FormBuilder,
            MenuController,
            DatePickerDirective,
            DeviceProvider,
            ToastProvider])
    ], RegistroPersonalDataPage);
    return RegistroPersonalDataPage;
}());
export { RegistroPersonalDataPage };
//# sourceMappingURL=personal-data.js.map