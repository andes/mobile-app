var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NavParams, NavController } from 'ionic-angular';
import { DatePickerDirective } from 'ion-datepicker';
import * as moment from 'moment';
// providers
import { AuthProvider } from '../../../providers/auth/auth';
// pages
import { VerificaCodigoPage } from '../verifica-codigo/verifica-codigo';
var WaitingValidationPage = (function () {
    function WaitingValidationPage(authService, navCtrl, navParams, formBuilder, datePicker) {
        var _this = this;
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.formBuilder = formBuilder;
        this.datePicker = datePicker;
        this.expand = false;
        this.usuario = this.navParams.get('user');
        this.formRegistro = formBuilder.group({
            nombre: ['', Validators.required],
            apellido: ['', Validators.required],
            documento: ['', Validators.required],
            sexo: ['', Validators.required],
            fechaNacimiento: ['', Validators.required],
        });
        // this.usuario.sexo = this.usuario.sexo.toLowerCase();
        this.formRegistro.patchValue(this.usuario);
        this.datePicker.valueChange.subscribe(function (date) {
            _this.formRegistro.patchValue({
                fechaNacimiento: moment(date).format('DD-MM-YYYY')
            });
        });
    }
    WaitingValidationPage.prototype.showCalendar = function () {
        this.datePicker.open();
    };
    WaitingValidationPage.prototype.ionViewDidLoad = function () {
        //
    };
    WaitingValidationPage.prototype.onBack = function () {
        this.navCtrl.pop();
    };
    WaitingValidationPage.prototype.onSubmit = function (_a) {
        var _this = this;
        var value = _a.value, valid = _a.valid;
        if (valid) {
            value.email = this.usuario.email;
            this.authService.updateAccount(value).then(function (data) {
                if (data.valid) {
                    _this.navCtrl.setRoot(VerificaCodigoPage);
                }
                else {
                    _this.expand = false;
                }
            }).catch(function () {
                // console.log('error');
            });
            // this.navCtrl.push(RegistroUserDataPage, { user: value });
        }
    };
    WaitingValidationPage.prototype.onKeyPress = function ($event, tag) {
        if ($event.keyCode === 13) {
            if (tag !== 'fecha') {
                var element = document.getElementById(tag);
                if (element) {
                    if (element.getElementsByTagName('input').length > 0) {
                        element.getElementsByTagName('input')[0].focus();
                    }
                    else if (element.getElementsByTagName('button').length > 0) {
                        element.getElementsByTagName('button')[0].focus();
                    }
                }
            }
            else {
                this.showCalendar();
            }
        }
    };
    WaitingValidationPage = __decorate([
        Component({
            selector: 'page-waiting-validation',
            templateUrl: 'waiting-validation.html',
            providers: [DatePickerDirective]
        }),
        __metadata("design:paramtypes", [AuthProvider,
            NavController,
            NavParams,
            FormBuilder,
            DatePickerDirective])
    ], WaitingValidationPage);
    return WaitingValidationPage;
}());
export { WaitingValidationPage };
//# sourceMappingURL=waiting-validation.js.map