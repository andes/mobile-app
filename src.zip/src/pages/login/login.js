var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
// Providers...
import { DeviceProvider } from '../../providers/auth/device';
import { AuthProvider } from '../../providers/auth/auth';
import { ToastProvider } from '../../providers/toast';
import { ConstanteProvider } from '../../providers/constantes';
// PAGES...
import { OrganizacionesPage } from './organizaciones/organizaciones';
import { VerificaCodigoPage } from '../registro/verifica-codigo/verifica-codigo';
import { InformacionValidacionPage } from '../registro/informacion-validacion/informacion-validacion';
import { RecuperarPasswordPage } from '../registro/recuperar-password/recuperar-password';
import { HomePage } from '../home/home';
import { RegistroUserDataPage } from '../registro/user-data/user-data';
import { NuevaPage } from '../gestion/nuevaPage';
var LoginPage = (function () {
    function LoginPage(assetsService, toastCtrl, deviceProvider, authService, loadingCtrl, navCtrl, navParams) {
        this.assetsService = assetsService;
        this.toastCtrl = toastCtrl;
        this.deviceProvider = deviceProvider;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.inProgress = false;
        this.emailRegex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        this.dniRegex = /^[0-9]{7,8}$/;
    }
    LoginPage.prototype.ionViewDidLoad = function () {
    };
    LoginPage.prototype.onKeyPress = function ($event, tag) {
        if ($event.keyCode === 13) {
            if (tag === 'submit') {
                this.login();
            }
            else {
                var element = document.getElementById(tag);
                if (element) {
                    element.focus();
                }
            }
        }
    };
    LoginPage.prototype.registro = function () {
        this.navCtrl.push(InformacionValidacionPage);
    };
    LoginPage.prototype.recuperarPassword = function () {
        this.navCtrl.push(RecuperarPasswordPage);
    };
    LoginPage.prototype.codigo = function () {
        this.navCtrl.push(VerificaCodigoPage);
    };
    LoginPage.prototype.login = function () {
        var _this = this;
        if (!this.email || !this.password) {
            this.toastCtrl.danger('Complete los datos para ingresar.');
            return;
        }
        if (!this.dniRegex.test(this.email)) {
            // Login pacientes
            var credentials = {
                email: this.email,
                password: this.password
            };
            this.inProgress = true;
            this.authService.login(credentials).then(function (result) {
                _this.inProgress = false;
                _this.deviceProvider.sync();
                _this.navCtrl.setRoot(HomePage);
            }, function (err) {
                _this.inProgress = false;
                if (err) {
                    if (err.message === 'new_password_needed') {
                        _this.navCtrl.push(RegistroUserDataPage, {
                            email: _this.email,
                            old_password: _this.password
                        });
                        // this.toastCtrl.danger("GOTO SET PASSWORD");
                    }
                    else {
                        _this.toastCtrl.danger('Email o password incorrecto.');
                    }
                }
            });
        }
        else {
            // Login profesional
            var credenciales = {
                usuario: this.email,
                password: this.password,
                mobile: true
            };
            this.inProgress = true;
            this.authService.loginProfesional(credenciales).then(function (resultado) {
                _this.inProgress = false;
                _this.deviceProvider.sync();
                var params = {
                    esGestion: resultado.user.esGestion ? resultado.user.esGestion : false,
                    mantenerSesion: resultado.user.mantenerSesion ? resultado.user.mantenerSesion : false
                };
                if (resultado.user && resultado.user.esGestion) {
                    // this.navCtrl.setRoot(NuevaPage, '1');
                    _this.navCtrl.setRoot(NuevaPage, params);
                }
                else {
                    _this.navCtrl.setRoot(OrganizacionesPage, params);
                }
            }).catch(function () {
                _this.inProgress = false;
                _this.toastCtrl.danger('Credenciales incorrectas');
            });
        }
    };
    LoginPage = __decorate([
        Component({
            selector: 'page-login',
            templateUrl: 'login.html',
        }),
        __metadata("design:paramtypes", [ConstanteProvider,
            ToastProvider,
            DeviceProvider,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams])
    ], LoginPage);
    return LoginPage;
}());
export { LoginPage };
//# sourceMappingURL=login.js.map