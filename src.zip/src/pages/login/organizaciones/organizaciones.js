var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';
// pages
// providers
import { DeviceProvider } from '../../../providers/auth/device';
import { ConstanteProvider } from '../../../providers/constantes';
import { AuthProvider } from '../../../providers/auth/auth';
import { ToastProvider } from '../../../providers/toast';
import { HomePage } from '../../home/home';
var OrganizacionesPage = (function () {
    function OrganizacionesPage(assetsService, navCtrl, navParams, deviceProvider, platform, toastCtrl, authProvider) {
        this.assetsService = assetsService;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.deviceProvider = deviceProvider;
        this.platform = platform;
        this.toastCtrl = toastCtrl;
        this.authProvider = authProvider;
        this.organizaciones = null;
        this.usuario = this.navParams.get('usuario');
        this.password = this.navParams.get('password');
    }
    OrganizacionesPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        console.log('gestion dsada', this.navParams.get('esGestion'));
        this.assetsService.getOrganizaciones(null).then(function (data) {
            _this.organizaciones = data;
            if (_this.organizaciones.length === 1) {
                _this.onOrganizacionClick(_this.organizaciones[0]);
            }
        });
    };
    OrganizacionesPage.prototype.onOrganizacionClick = function (organizacion) {
        var _this = this;
        this.authProvider.selectOrganizacion({ organizacion: organizacion.id }).then(function () {
            _this.navCtrl.setRoot(HomePage);
        }).catch(function () {
            _this.toastCtrl.danger('Credenciales incorrectas');
        });
    };
    OrganizacionesPage = __decorate([
        Component({
            selector: 'page-organizaciones',
            templateUrl: 'organizaciones.html'
        }),
        __metadata("design:paramtypes", [ConstanteProvider,
            NavController,
            NavParams,
            DeviceProvider,
            Platform,
            ToastProvider,
            AuthProvider])
    ], OrganizacionesPage);
    return OrganizacionesPage;
}());
export { OrganizacionesPage };
//# sourceMappingURL=organizaciones.js.map