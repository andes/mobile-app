var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NavController, NavParams, LoadingController, MenuController, Platform } from 'ionic-angular';
import * as moment from 'moment';
import { Camera } from '@ionic-native/camera';
import { Crop } from '@ionic-native/crop';
import { ImageResizer } from '@ionic-native/image-resizer';
import { Base64 } from '@ionic-native/base64';
import { PhotoViewer } from '@ionic-native/photo-viewer';
import { DomSanitizer } from '@angular/platform-browser';
import { NativeGeocoder } from '@ionic-native/native-geocoder';
// pages
import { DondeVivoDondeTrabajoPage } from './donde-vivo-donde-trabajo/donde-vivo-donde-trabajo';
// providers
import { AlertController } from 'ionic-angular';
import { AuthProvider } from '../../../providers/auth/auth';
import { EditorPacientePage } from '../editor-paciente/editor-paciente';
import { Storage } from '@ionic/storage';
import { PacienteProvider } from '../../../providers/paciente';
import { ConstanteProvider } from '../../../providers/constantes';
import { ToastProvider } from '../../../providers/toast';
var ProfilePacientePage = (function () {
    function ProfilePacientePage(storage, authService, loadingCtrl, navCtrl, navParams, alertCtrl, formBuilder, menu, pacienteProvider, assetProvider, toast, camera, cropService, imageResizer, base64, photoViewer, sanitizer, nativeGeocoder, platform) {
        // this.menu.swipeEnable(false);
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.menu = menu;
        this.pacienteProvider = pacienteProvider;
        this.assetProvider = assetProvider;
        this.toast = toast;
        this.camera = camera;
        this.cropService = cropService;
        this.imageResizer = imageResizer;
        this.base64 = base64;
        this.photoViewer = photoViewer;
        this.sanitizer = sanitizer;
        this.nativeGeocoder = nativeGeocoder;
        this.platform = platform;
        this.emailRegex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        this.phoneRegex = /^[1-3][0-9]{9}$/;
        this.showPersonal = false;
        this.showContactos = false;
        this.showDondeVivo = false;
        this.showDondeTrabajo = false;
        this.contactType = [
            'celular',
            'fijo'
        ];
        this.paciente = null;
        this.direccion = '';
        this.provincias = [];
        this.localidades = [];
        this.direccionDondeVivo = {};
        this.direccionDondeTrabajo = {};
        this.photo = 'assets/img/user-profile-blank.jpg';
        this.inProgress = false;
        this.loading = null;
    }
    ProfilePacientePage.prototype.fechaNacimiento = function () {
        return moment(this.paciente.fechaNacimiento).format('DD/MM/YYYY');
    };
    ProfilePacientePage.prototype.ionViewDidLoad = function () {
        var _this = this;
        var pacienteId = this.authService.user.pacientes[0].id;
        this.inProgress = true;
        this.pacienteProvider.get(pacienteId).then(function (paciente) {
            _this.inProgress = false;
            _this.paciente = paciente;
            _this.contactos = paciente.contacto;
            _this.direcciones = paciente.direccion;
            _this.telefonos = paciente.contacto.filter(function (item) { return item.tipo !== 'email'; });
            _this.emails = paciente.contacto.filter(function (item) { return item.tipo === 'email'; });
            _this.telefonos.push({ tipo: 'celular', valor: '' });
            _this.emails.push({ tipo: 'email', valor: '' });
            if (_this.paciente.fotoMobile) {
                _this.photo = _this.sanitizer.bypassSecurityTrustResourceUrl(_this.paciente.fotoMobile);
            }
            // preparamos la direccion de trabajo
            // this.direccionDondeTrabajo = paciente.direccion.find( item => item.ranking == 1);
        }).catch(function () {
            _this.inProgress = false;
        });
    };
    ProfilePacientePage.prototype.ionViewDidEnter = function () {
    };
    ProfilePacientePage.prototype.onInputChange = function (list, newType) {
        var last = list.length - 1;
        if (list[last].valor.length > 0) {
            list.push({ tipo: newType, valor: '' });
        }
        else if (list.length > 1 && list[last - 1].valor.length === 0) {
            list.pop();
        }
    };
    ProfilePacientePage.prototype.reportarChange = function () {
        // console.log('Cucumbers new state:' + this.reportarError);
    };
    ProfilePacientePage.prototype.togglePersonales = function () {
        if (this.showPersonal) {
            this.showPersonal = false;
        }
        else {
            this.showPersonal = true;
            this.showContactos = this.showDondeTrabajo = this.showDondeVivo = false;
        }
    };
    ProfilePacientePage.prototype.toggleContactos = function () {
        if (this.showContactos) {
            this.showContactos = false;
        }
        else {
            this.showContactos = true;
            this.showPersonal = this.showDondeTrabajo = this.showDondeVivo = false;
        }
    };
    ProfilePacientePage.prototype.toggleDondeVivo = function () {
        if (this.showDondeVivo) {
            this.showDondeVivo = false;
        }
        else {
            this.showDondeVivo = true;
            this.showContactos = this.showPersonal = this.showDondeTrabajo = false;
        }
    };
    ProfilePacientePage.prototype.abrirDondeVivo = function () {
        this.navCtrl.push(DondeVivoDondeTrabajoPage, { tipo: 'Donde vivo' });
    };
    ProfilePacientePage.prototype.abrirDondeTrabajo = function () {
        this.navCtrl.push(DondeVivoDondeTrabajoPage, { tipo: 'Donde trabajo' });
    };
    ProfilePacientePage.prototype.toggleDondeTrabajo = function () {
        if (this.showDondeTrabajo) {
            this.showDondeTrabajo = false;
        }
        else {
            this.showDondeTrabajo = true;
            this.showContactos = this.showPersonal = this.showDondeTrabajo = false;
        }
    };
    ProfilePacientePage.prototype.onEdit = function () {
        this.navCtrl.push(EditorPacientePage, { paciente: this.paciente });
    };
    ProfilePacientePage.prototype.onSave = function () {
        var _this = this;
        var canSave = false;
        this.telefonos.splice(-1, 1);
        this.emails.splice(-1, 1);
        this.contactos = this.telefonos.concat(this.emails);
        for (var i = 0; i < this.contactos.length; i++) {
            var contacto = this.contactos[i];
            switch (contacto.tipo) {
                case 'email':
                    if (!this.emailRegex.test(contacto.valor)) {
                        this.toast.danger('EMAIL INVALIDO');
                        this.telefonos.push({ tipo: 'celular', valor: '' });
                        this.emails.push({ tipo: 'email', valor: '' });
                        return;
                    }
                    break;
                case 'fijo':
                case 'celular':
                    if (!this.phoneRegex.test(contacto.valor)) {
                        this.toast.danger('TELEFONO INVALIDO');
                        this.telefonos.push({ tipo: 'celular', valor: '' });
                        this.emails.push({ tipo: 'email', valor: '' });
                        return;
                    }
                    break;
            }
        }
        if (this.contactos.length > 0) {
            canSave = true;
        }
        if (!canSave) {
            this.telefonos.push({ tipo: 'celular', valor: '' });
            this.emails.push({ tipo: 'email', valor: '' });
            this.toast.danger('Debe indicar al menos un número de teléfono o email');
            return false;
        }
        var data = {
            contacto: this.contactos
        };
        this.pacienteProvider.update(this.paciente.id, data).then(function () {
            _this.toast.success('DATOS MODIFICADOS CORRECTAMENTE');
            _this.telefonos.push({ tipo: 'celular', valor: '' });
            _this.emails.push({ tipo: 'email', valor: '' });
            // this.navCtrl.setRoot(TurnosPage);
        });
    };
    ProfilePacientePage.prototype.takePhoto = function () {
        // let options = {
        //   quality: 80, // 80
        //   correctOrientation: true,
        //   destinationType: 2 // NATIVE_URI
        // } as CameraOptions;
        // // sacamos la foto
        // this.camera.getPicture(options).then((imageData) => {
        //   // cropeamos la foto que sacamos
        //   this.cropService.crop(imageData, { quality: 75 }).then((imageCropped) => {
        //     // por ultimo hacemos un resize
        //     let optionsResize = {
        //       uri: imageCropped,
        //       folderName: 'andes',
        //       quality: 50, //70
        //       width: 600,
        //       height: 600
        //     } as ImageResizerOptions;
        //     this.imageResizer.resize(optionsResize).then((filePath: string) => {
        //       // transformamos la foto en base64 para poder guardar en la base
        //       this.base64.encodeFile(filePath).then((base64File: string) => {
        //         // debemos sanatizar si o si el archivo en base64 generado para
        //         // poder mostrarlo en el browser y evitar ataques xss o lo que sea
        //         // Ref: https://angular.io/guide/security#xss
        //         this.showLoader();
        //         this.pacienteProvider.patch(this.paciente.id, { op: 'updateFotoMobile', fotoMobile: this.photo.changingThisBreaksApplicationSecurity }).then(() => {
        //           this.photo = this.sanitizer.bypassSecurityTrustResourceUrl(base64File);
        //           this.loading.dismiss();
        //           this.toast.success('Foto de perfil actualizada');
        //         }, error => {
        //           this.loading.dismiss();
        //           this.toast.danger('Error al sacar la foto.');
        //         });
        //       }, (err) => {
        //         this.toast.danger('Error al sacar la foto.');
        //       });
        //     }).catch(e => {
        //       this.toast.danger('Error al sacar la foto.');
        //     });
        //   }, (error) => {
        //     this.toast.danger('Error al sacar la foto.');
        //   });
        // }, (err) => {
        //   this.toast.danger('Error al sacar la foto.');
        // });
    };
    ProfilePacientePage.prototype.showLoader = function () {
        this.loading = this.loadingCtrl.create({
            content: 'Actualizando foto...'
        });
        this.loading.present();
    };
    ProfilePacientePage.prototype.openPhoto = function () {
        this.photoViewer.show(this.photo);
    };
    ProfilePacientePage = __decorate([
        Component({
            selector: 'page-profile-paciente',
            templateUrl: 'profile-paciente.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            AlertController,
            FormBuilder,
            MenuController,
            PacienteProvider,
            ConstanteProvider,
            ToastProvider,
            Camera,
            Crop,
            ImageResizer,
            Base64,
            PhotoViewer,
            DomSanitizer,
            NativeGeocoder,
            Platform])
    ], ProfilePacientePage);
    return ProfilePacientePage;
}());
export { ProfilePacientePage };
//# sourceMappingURL=profile-paciente.js.map