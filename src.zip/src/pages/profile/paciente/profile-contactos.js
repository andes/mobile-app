var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NavController, NavParams, LoadingController, Platform } from 'ionic-angular';
// providers
import { AlertController } from 'ionic-angular';
import { AuthProvider } from '../../../providers/auth/auth';
import { EditorPacientePage } from '../editor-paciente/editor-paciente';
import { Storage } from '@ionic/storage';
import { PacienteProvider } from '../../../providers/paciente';
import { ConstanteProvider } from '../../../providers/constantes';
import { ToastProvider } from '../../../providers/toast';
var ProfileContactosPage = (function () {
    function ProfileContactosPage(storage, authService, loadingCtrl, navCtrl, navParams, alertCtrl, formBuilder, pacienteProvider, assetProvider, toast, platform) {
        // this.menu.swipeEnable(false);
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.pacienteProvider = pacienteProvider;
        this.assetProvider = assetProvider;
        this.toast = toast;
        this.platform = platform;
        this.emailRegex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        this.phoneRegex = /^[1-3][0-9]{9}$/;
        this.contactType = [
            'celular',
            'fijo'
        ];
        this.paciente = null;
        this.inProgress = false;
    }
    ProfileContactosPage.prototype.ionViewDidLoad = function () {
        this.paciente = this.pacienteProvider.paciente;
        var emailData = this.paciente.contacto.find(function (item) { return item.tipo === 'email'; });
        if (emailData) {
            this._email = emailData.valor;
        }
        var phoneData = this.paciente.contacto.find(function (item) { return item.tipo === 'celular'; });
        if (phoneData) {
            this._telefono = phoneData.valor;
        }
    };
    ProfileContactosPage.prototype.ionViewDidEnter = function () {
    };
    ProfileContactosPage.prototype.reportarChange = function () {
        // console.log('Cucumbers new state:' + this.reportarError);
    };
    ProfileContactosPage.prototype.onEdit = function () {
        this.navCtrl.push(EditorPacientePage, { paciente: this.paciente });
    };
    ProfileContactosPage.prototype.onSave = function () {
        var _this = this;
        var contactos = [];
        if (this._telefono.length && !this.phoneRegex.test(this._telefono)) {
            this.toast.danger('CELULAR INCORRECTO');
            return;
        }
        if (this._email.length && !this.emailRegex.test(this._email)) {
            this.toast.danger('EMAIL INCORRECTO');
            return;
        }
        if (this._telefono.length) {
            contactos.push({
                tipo: 'celular',
                valor: this._telefono
            });
        }
        if (this._email.length) {
            contactos.push({
                tipo: 'email',
                valor: this._email
            });
        }
        var data = {
            contacto: contactos
        };
        this.pacienteProvider.update(this.paciente.id, data).then(function () {
            _this.toast.success('DATOS MODIFICADOS CORRECTAMENTE');
        });
    };
    ProfileContactosPage = __decorate([
        Component({
            selector: 'page-profile-contacto',
            templateUrl: 'profile-contactos.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            AlertController,
            FormBuilder,
            PacienteProvider,
            ConstanteProvider,
            ToastProvider,
            Platform])
    ], ProfileContactosPage);
    return ProfileContactosPage;
}());
export { ProfileContactosPage };
//# sourceMappingURL=profile-contactos.js.map