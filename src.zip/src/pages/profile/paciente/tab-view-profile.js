var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Tabs } from 'ionic-angular';
import { ProfilePacientePage } from './profile-paciente';
import { DondeVivoDondeTrabajoPage } from './donde-vivo-donde-trabajo/donde-vivo-donde-trabajo';
import { ProfileContactosPage } from './profile-contactos';
import { ErrorReporterProvider } from '../../../providers/errorReporter';
/**
 * Generated class for the CentrosSaludPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
var TabViewProfilePage = (function () {
    function TabViewProfilePage(navCtrl, navParams, reporter) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.reporter = reporter;
        this.subtitle = '';
        this.tab1Root = ProfilePacientePage;
        this.tab2Root = DondeVivoDondeTrabajoPage;
        this.tab3Root = ProfileContactosPage;
    }
    TabViewProfilePage.prototype.ionViewDidLoad = function () {
        this.reporter.alert();
    };
    TabViewProfilePage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    TabViewProfilePage.prototype.onTabChange = function () {
        switch (this.tabRef.getSelected().index) {
            case 0:
                this.subtitle = 'Personales';
                break;
            case 1:
                this.subtitle = 'Dirección';
                break;
            case 2:
                this.subtitle = 'Contacto';
                break;
        }
    };
    __decorate([
        ViewChild('tabs'),
        __metadata("design:type", Tabs)
    ], TabViewProfilePage.prototype, "tabRef", void 0);
    TabViewProfilePage = __decorate([
        Component({
            selector: 'tab-view-profle',
            templateUrl: 'tab-view-profile.html',
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            ErrorReporterProvider])
    ], TabViewProfilePage);
    return TabViewProfilePage;
}());
export { TabViewProfilePage };
//# sourceMappingURL=tab-view-profile.js.map