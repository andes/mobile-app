var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { AuthProvider } from '../../../providers/auth/auth';
import { Storage } from '@ionic/storage';
import { PacienteProvider } from '../../../providers/paciente';
import { ToastProvider } from '../../../providers/toast';
var EditorPacientePage = (function () {
    function EditorPacientePage(storage, authService, loadingCtrl, navCtrl, navParams, alertCtrl, formBuilder, menu, pacienteProvider, toast) {
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.menu = menu;
        this.pacienteProvider = pacienteProvider;
        this.toast = toast;
        this.fase = 1;
        this.submit = false;
        // this.menu.swipeEnable(false);
        this.paciente = this.pacienteProvider.paciente;
        this.formRegistro = formBuilder.group({
            nombre: ['', Validators.required],
            apellido: ['', Validators.required],
            // telefono: ['', Validators.required],
            // documento: ['', Validators.required],
            sexo: ['', Validators.required],
            // genero: ['', Validators.required],
            // fechaNacimiento: ['', Validators.required],
            nacionalidad: ['', Validators.required],
        });
        this.formRegistro.patchValue({
            nombre: this.paciente.nombre,
            apellido: this.paciente.apellido,
            sexo: this.paciente.sexo,
            nacionalidad: this.paciente.nacionalidad
        });
    }
    EditorPacientePage.prototype.ionViewDidLoad = function () {
        //
    };
    EditorPacientePage.prototype.onEdit = function () {
        var _this = this;
        var notas = JSON.stringify(this.formRegistro.value);
        var data = {
            reportarError: true,
            notas: notas
        };
        this.pacienteProvider.update(this.paciente.id, data).then(function () {
            _this.navCtrl.pop();
            _this.toast.success('SOLICITUD ENVIADA CON EXITO!');
        }).catch(function () {
            _this.toast.danger('ERROR AL MANDAR LA SOLICITUD');
        });
    };
    EditorPacientePage = __decorate([
        Component({
            selector: 'page-editor-paciente',
            templateUrl: 'editor-paciente.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            AlertController,
            FormBuilder,
            MenuController,
            PacienteProvider,
            ToastProvider])
    ], EditorPacientePage);
    return EditorPacientePage;
}());
export { EditorPacientePage };
//# sourceMappingURL=editor-paciente.js.map