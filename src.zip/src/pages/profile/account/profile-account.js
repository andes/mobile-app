var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HomePage } from './../../home/home';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, MenuController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { AuthProvider } from '../../../providers/auth/auth';
import { Storage } from '@ionic/storage';
import { ToastProvider } from '../../../providers/toast';
var ProfileAccountPage = (function () {
    function ProfileAccountPage(storage, authService, loadingCtrl, navCtrl, navParams, alertCtrl, menu, toast) {
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.menu = menu;
        this.toast = toast;
        this.fase = 1;
        this.submit = false;
        this.expand = false;
        this.password = '';
        this.password2 = '';
        this.old_password = '';
        this.emailRegex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        this.phoneRegex = /^[1-3][0-9]{9}$/;
        this.email = this.authService.user.email;
        this.telefono = this.authService.user.telefono;
    }
    ProfileAccountPage.prototype.ionViewDidLoad = function () {
    };
    ProfileAccountPage.prototype.ionViewDidEnter = function () {
    };
    ProfileAccountPage.prototype.onSave = function () {
        var _this = this;
        var data = {};
        if (this.telefono !== this.authService.user.telefono) {
            if (!this.phoneRegex.test(this.telefono)) {
                this.toast.danger('INGRESE UN CELULAR CORRECTO');
                return;
            }
            data.telefono = this.telefono;
        }
        if (this.email !== this.authService.user.email) {
            if (this.emailRegex.test(this.email)) {
                data.email = this.email;
            }
            else {
                this.toast.danger('INGRESE UN EMAIL CORRECTO');
                return;
            }
        }
        if (this.expand && (!this.password.length && !this.old_password.length && !this.password2.length)) {
            this.toast.danger('DEBERÁ COMPLETAR TODOS LOS CAMPOS PARA CAMBIAR SU CONTRASEÑA');
            return;
        }
        if (this.password.length + this.old_password.length + this.password2.length > 0) {
            if (this.old_password.length === 0) {
                this.toast.danger('INGRESE CORRECTAMENTE SU CONTRASEÑA ACTUAL');
                return;
            }
            if (this.password.length === 0 || this.password !== this.password2) {
                this.toast.danger('INGRESE CORRECTAMENTE LA CONTRASEÑA NUEVA');
                return;
            }
            data.password = this.password;
            data.old_password = this.old_password;
        }
        this.loading = true;
        this.authService.update(data).then(function (_data) {
            _this.loading = false;
            _this.toast.success('DATOS MODIFICADOS CORRECTAMENTE');
            _this.navCtrl.setRoot(HomePage);
        }).catch(function (err) {
            _this.loading = false;
            if (err.email) {
                _this.toast.danger('EMAIL INCORRECTO');
            }
            else {
                _this.toast.danger('CONTRASEÑA ACTUAL INCORRECTA');
            }
        });
    };
    ProfileAccountPage = __decorate([
        Component({
            selector: 'page-profile-account',
            templateUrl: 'profile-account.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            AlertController,
            MenuController,
            ToastProvider])
    ], ProfileAccountPage);
    return ProfileAccountPage;
}());
export { ProfileAccountPage };
//# sourceMappingURL=profile-account.js.map