var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, Platform } from 'ionic-angular';
import { LocationsProvider } from '../../../providers/locations/locations';
import { GeoProvider } from '../../../providers/geo-provider';
// providers
import { AgendasProvider } from '../../../providers/agendas';
import { TurnosProvider } from '../../../providers/turnos';
import { CheckerGpsProvider } from '../../../providers/locations/checkLocation';
import { ToastProvider } from '../../../providers/toast';
import { ErrorReporterProvider } from '../../../providers/errorReporter';
// Pages
import { TurnosCalendarioPage } from '../calendario/turnos-calendario';
var TurnosBuscarPage = (function () {
    function TurnosBuscarPage(navCtrl, turnosProvider, agendasProvider, navParams, locations, gMaps, checker, alertCtrl, toast, reporter, platform) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.turnosProvider = turnosProvider;
        this.agendasProvider = agendasProvider;
        this.navParams = navParams;
        this.locations = locations;
        this.gMaps = gMaps;
        this.checker = checker;
        this.alertCtrl = alertCtrl;
        this.toast = toast;
        this.reporter = reporter;
        this.platform = platform;
        this.efectores = null;
        this.position = {};
        this.myPosition = null;
        this.prestacion = this.navParams.get('prestacion');
        this.onResumeSubscription = platform.resume.subscribe(function () {
            _this.checker.checkGPS();
        });
    }
    TurnosBuscarPage.prototype.ngOnDestroy = function () {
        // always unsubscribe your subscriptions to prevent leaks
        this.onResumeSubscription.unsubscribe();
    };
    TurnosBuscarPage.prototype.ionViewDidLoad = function () {
        this.getTurnosDisponibles();
    };
    TurnosBuscarPage.prototype.getTurnosDisponibles = function () {
        var _this = this;
        if (this.gMaps.actualPosition) {
            var userLocation = { lat: this.gMaps.actualPosition.latitude, lng: this.gMaps.actualPosition.longitude };
            this.getTurnosDisponiblesAux(userLocation);
        }
        else {
            this.gMaps.getGeolocation().then(function (position) {
                var userLocation = { lat: position.coords.latitude, lng: position.coords.longitude };
                _this.getTurnosDisponiblesAux(userLocation);
            });
        }
    };
    TurnosBuscarPage.prototype.getTurnosDisponiblesAux = function (userLocation) {
        var _this = this;
        this.agendasProvider.getAgendasDisponibles({ prestacion: this.prestacion, userLocation: userLocation }).then(function (data) {
            _this.efectores = data;
        }).catch(function (err) {
            _this.toast.danger('Ups... se ha producido un error, reintentar.');
        });
    };
    TurnosBuscarPage.prototype.mostrarEfector = function (efector) {
        return efector.organizacion;
    };
    TurnosBuscarPage.prototype.turnosDisponibles = function (efector) {
        var agendasEfector = [];
        var listaTurnosDisponibles = [];
        agendasEfector.forEach(function (agenda) {
            agenda.bloques.forEach(function (bloque) {
                bloque.turnos.forEach(function (turno) {
                    if (turno.estado === 'disponible') {
                        listaTurnosDisponibles.push(turno);
                    }
                });
            });
        });
        return listaTurnosDisponibles;
    };
    TurnosBuscarPage.prototype.buscarTurno = function (efector) {
        this.navCtrl.push(TurnosCalendarioPage, { efector: efector, prestacion: this.prestacion });
    };
    TurnosBuscarPage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    TurnosBuscarPage = __decorate([
        Component({
            selector: 'page-turnos-buscar',
            templateUrl: 'turnos-buscar.html'
        }),
        __metadata("design:paramtypes", [NavController,
            TurnosProvider,
            AgendasProvider,
            NavParams,
            LocationsProvider,
            GeoProvider,
            CheckerGpsProvider,
            AlertController,
            ToastProvider,
            ErrorReporterProvider,
            Platform])
    ], TurnosBuscarPage);
    return TurnosBuscarPage;
}());
export { TurnosBuscarPage };
//# sourceMappingURL=turnos-buscar.js.map