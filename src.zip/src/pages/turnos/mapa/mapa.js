var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { NavController, NavParams, Platform } from 'ionic-angular';
import { Component } from '@angular/core';
// Providers
import { CheckerGpsProvider } from '../../../providers/locations/checkLocation';
import { GeoProvider } from '../../../providers/geo-provider';
var MapTurnosPage = (function () {
    function MapTurnosPage(navCtrl, navParams, platform, checker, maps) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.platform = platform;
        this.checker = checker;
        this.maps = maps;
        this.myPosition = null;
        this.centro = null;
        this.zoom = 14;
        this._locationsSubscriptions = null;
        this.checker.checkGPS();
        this.centro = this.navParams.get('centro');
    }
    MapTurnosPage.prototype.ngOnDestroy = function () {
        if (this._locationsSubscriptions) {
            this._locationsSubscriptions.unsubscribe();
        }
        if (this.geoSubcribe) {
            this.geoSubcribe.unsubscribe();
        }
    };
    MapTurnosPage.prototype.navigateTo = function () {
        if (this.platform.is('ios')) {
            window.open('maps://?q=' + this.centro.location.latitud + ',' + this.centro.location.longitud, '_system');
        }
        ;
        if (this.platform.is('android')) {
            window.open('geo:?q=' + this.centro.location.latitud + ',' + this.centro.location.longitud);
        }
        ;
    };
    MapTurnosPage = __decorate([
        Component({
            selector: 'turnos-mapa',
            templateUrl: 'mapa.html',
            styles: ["\n        agm-map {\n            height: 100%;\n            width: 100%;\n        }\n    "],
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            Platform,
            CheckerGpsProvider,
            GeoProvider])
    ], MapTurnosPage);
    return MapTurnosPage;
}());
export { MapTurnosPage };
//# sourceMappingURL=mapa.js.map