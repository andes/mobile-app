var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Output, EventEmitter } from '@angular/core';
import { NavController, NavParams, AlertController, Platform } from 'ionic-angular';
import * as moment from 'moment/moment';
// pages
import { TurnosPage } from '../turnos';
import { HomePage } from '../../home/home';
import { MapTurnosPage } from '../mapa/mapa';
// providers
import { TurnosProvider } from '../../../providers/turnos';
import { ToastProvider } from '../../../providers/toast';
var TurnosDetallePage = (function () {
    function TurnosDetallePage(navCtrl, turnosProvider, navParams, toast, alertCtrl, platform) {
        this.navCtrl = navCtrl;
        this.turnosProvider = turnosProvider;
        this.navParams = navParams;
        this.toast = toast;
        this.alertCtrl = alertCtrl;
        this.platform = platform;
        this.onCancelEvent = new EventEmitter();
        this.turno = this.navParams.get('turno');
        this.turnoAsignado = this.turno.estado === 'asignado' ? true : false;
    }
    TurnosDetallePage.prototype.profesionalName = function () {
        if (this.turno.profesionales.length > 0) {
            return this.turno.profesionales[0].apellido + ' ' + this.turno.profesionales[0].nombre;
        }
        else {
            return 'Sin profesional';
        }
    };
    TurnosDetallePage.prototype.turnoFecha = function () {
        return moment(this.turno.horaInicio).format('DD/MM/YY');
    };
    TurnosDetallePage.prototype.turnoHora = function () {
        return moment(this.turno.horaInicio).format('HH:mm');
    };
    TurnosDetallePage.prototype.isAsignado = function () {
        return this.turno.estado === 'asignado' ? true : false;
    };
    TurnosDetallePage.prototype.cancelarTurno = function () {
        var _this = this;
        this.showConfirm('¿Seguro desea cancelar este turno?', '').then(function () {
            var params = {
                turno_id: _this.turno._id,
                agenda_id: _this.turno.agenda_id,
                bloque_id: _this.turno.bloque_id
            };
            _this.turnosProvider.cancelarTurno(params).then(function (resultado) {
                _this.onCancelEvent.emit(_this.turno);
                _this.navCtrl.push(TurnosPage).then(function () {
                    _this.toast.success('El turno fue liberado correctamente');
                    _this.navCtrl.setRoot(HomePage);
                    _this.navCtrl.popToRoot();
                });
            }).catch(function (err2) {
                _this.toast.danger('Ocurrió un error al cancelar el turno, reintente más tarde');
                _this.navCtrl.push(HomePage);
            });
        }).catch(function () { });
    };
    TurnosDetallePage.prototype.showConfirm = function (title, message) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var confirm = _this.alertCtrl.create({
                title: title,
                message: message,
                buttons: [
                    {
                        text: 'Cancelar',
                        handler: function () {
                            reject();
                        }
                    },
                    {
                        text: 'Aceptar',
                        handler: function () {
                            resolve();
                        }
                    }
                ]
            });
            confirm.present();
        });
    };
    TurnosDetallePage.prototype.efector = function () {
        return this.turno.organizacion.nombre;
    };
    TurnosDetallePage.prototype.mapTurno = function () {
        var _this = this;
        var idOrganizacion = this.turno.organizacion._id;
        this.turnosProvider.getUbicacionTurno(idOrganizacion).then(function (data) {
            var centro = {
                nombre: data._doc.nombre,
                domicilio: {
                    direccion: data._doc.direccion.valor
                },
                location: {
                    latitud: data.coordenadasDeMapa.latitud,
                    longitud: data.coordenadasDeMapa.longitud
                }
            };
            _this.navCtrl.push(MapTurnosPage, { centro: centro });
        });
    };
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], TurnosDetallePage.prototype, "onCancelEvent", void 0);
    TurnosDetallePage = __decorate([
        Component({
            selector: 'page-turno-detalle',
            templateUrl: 'turno-detalle.html'
        }),
        __metadata("design:paramtypes", [NavController,
            TurnosProvider,
            NavParams,
            ToastProvider,
            AlertController,
            Platform])
    ], TurnosDetallePage);
    return TurnosDetallePage;
}());
export { TurnosDetallePage };
//# sourceMappingURL=turno-detalle.js.map