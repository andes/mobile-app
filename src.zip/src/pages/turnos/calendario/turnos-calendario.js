var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, Platform } from 'ionic-angular';
// providers
import { AgendasProvider } from '../../../providers/agendas';
import { TurnosProvider } from '../../../providers/turnos';
import { ToastProvider } from '../../../providers/toast';
import { AuthProvider } from '../../../providers/auth/auth';
import { PacienteProvider } from '../../../providers/paciente';
// page
import { HomePage } from '../../home/home';
import { ErrorReporterProvider } from '../../../providers/errorReporter';
var TurnosCalendarioPage = (function () {
    function TurnosCalendarioPage(navCtrl, turnosProvider, agendasProvider, navParams, authService, pacienteProvider, toast, alertCtrl, reporter, platform) {
        this.navCtrl = navCtrl;
        this.turnosProvider = turnosProvider;
        this.agendasProvider = agendasProvider;
        this.navParams = navParams;
        this.authService = authService;
        this.pacienteProvider = pacienteProvider;
        this.toast = toast;
        this.alertCtrl = alertCtrl;
        this.reporter = reporter;
        this.platform = platform;
        this.confirmado = false;
        this.turnoToShow = null;
        this.showConfirmationSplash = false;
        this.efector = this.navParams.get('efector');
        this.prestacion = this.navParams.get('prestacion');
        this.agendas = this.efector.agendas;
    }
    TurnosCalendarioPage.prototype.ionViewDidLoad = function () {
        // para solucionar el bug de navegabilidad (mejorar más adelante)
        this.refreshAgendas();
    };
    TurnosCalendarioPage.prototype.agruparTurnosPorSegmento = function (turnos) {
        var _this = this;
        var turnosGrouped = [];
        turnos.forEach(function (turno) {
            if (!_this.findObjectByKey(turnosGrouped, 'horaInicio', turno.horaInicio) && turno.estado === 'disponible') {
                turnosGrouped.push(turno);
            }
        });
        return turnosGrouped;
    };
    TurnosCalendarioPage.prototype.mostrarEfector = function (agenda) {
        return agenda.organizacion;
    };
    TurnosCalendarioPage.prototype.mostrarProfesionales = function (profesionales) {
        if (profesionales.length > 0) {
            return (profesionales[0].apellido + ' ' + profesionales[0].nombre);
        }
        else {
            return 'Sin profesional';
        }
    };
    TurnosCalendarioPage.prototype.disponible = function (turno) {
        return turno.estado === 'disponible';
    };
    TurnosCalendarioPage.prototype.confirmar = function (agenda, bloque, turno) {
        var _this = this;
        this.confirmado = true;
        var pacienteId = this.authService.user.pacientes[0].id;
        var prestacion = this.prestacion;
        this.pacienteProvider.get(pacienteId).then(function (paciente) {
            var pacienteSave = {
                id: paciente.id,
                documento: paciente.documento,
                apellido: paciente.apellido,
                nombre: paciente.nombre,
                alias: paciente.alias,
                fechaNacimiento: paciente.fechaNacimiento,
                sexo: paciente.sexo,
                telefono: paciente.contacto,
                carpetaEfectores: paciente.carpetaEfectores
            };
            // Datos del Turno
            var datosTurno = {
                idAgenda: agenda._id,
                idTurno: turno._id,
                idBloque: bloque._id,
                paciente: pacienteSave,
                tipoPrestacion: prestacion,
                tipoTurno: 'programado',
                emitidoPor: 'appMobile',
                nota: 'Turno pedido desde app móvil',
                motivoConsulta: ''
            };
            _this.agendasProvider.save(datosTurno, { showError: false }).then(function () {
                _this.toast.success('Turno asignado correctamente', 800, function () {
                    _this.navCtrl.push(HomePage).then(function () {
                        _this.navCtrl.setRoot(HomePage);
                        _this.navCtrl.popToRoot();
                    });
                });
            }).catch(function () {
                _this.toast.danger('El turno ya no está disponible, seleccione otro turno.', 800);
                _this.refreshAgendas();
                _this.confirmado = false;
            });
        }).catch(function (err) {
            _this.toast.danger('Error en la confirmación del turno, intente nuevamente');
            _this.confirmado = false;
        });
    };
    TurnosCalendarioPage.prototype.cancelar = function () {
        this.refreshAgendas();
    };
    TurnosCalendarioPage.prototype.refreshAgendas = function () {
        var _this = this;
        this.agendas.sort(function (agendaA, agendaB) {
            return new Date(agendaA.horaInicio).getTime() - new Date(agendaB.horaInicio).getTime();
        });
        this.agendas.forEach(function (agenda) {
            _this.agendasProvider.getById(agenda._id).then(function (agendaRefresh) {
                var indice = _this.agendas.indexOf(agenda);
                if (indice !== -1) {
                    _this.agendas.splice(indice, 1);
                }
                _this.agendas.splice(indice, 0, agendaRefresh);
                // this.agendas = this.filtrarAgendas(this.agendas);
                _this.showConfirmationSplash = false;
            });
        });
    };
    TurnosCalendarioPage.prototype.confirmationSplash = function (agenda, bloque, turno) {
        this.turnoToShow = {
            fecha: turno.horaInicio,
            prestacion: this.prestacion.term,
            profesional: this.mostrarProfesionales(agenda.profesionales),
            efector: agenda.organizacion.nombre,
            nota: 'Si Ud. no puede concurrir al turno por favor recuerde cancelarlo a través de esta aplicación móvil, o comunicándose telefónicamente al Centro de Salud, para que otro paciente pueda tomarlo. ¡Muchas gracias!',
            a: agenda,
            b: bloque,
            t: turno
        };
        this.showConfirmationSplash = true;
    };
    TurnosCalendarioPage.prototype.turnosDisponibles = function (ag) {
        var hayDisponibles = false;
        ag.bloques.forEach(function (bloque) {
            bloque.turnos.forEach(function (turno) {
                if (turno.estado === 'disponible') {
                    return hayDisponibles = true;
                }
            });
        });
        return hayDisponibles;
    };
    TurnosCalendarioPage.prototype.findObjectByKey = function (array, key, value) {
        for (var i = 0; i < array.length; i++) {
            if (array[i][key] === value) {
                return array[i];
            }
        }
        return null;
    };
    TurnosCalendarioPage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    TurnosCalendarioPage.prototype.incluyePrestacion = function (bloque) {
        var _this = this;
        var arr = bloque.tipoPrestaciones.find(function (item) { return item.conceptId === _this.prestacion.conceptId; });
        if (arr) {
            return true;
        }
        else {
            return false;
        }
    };
    TurnosCalendarioPage = __decorate([
        Component({
            selector: 'page-turnos-calendario',
            templateUrl: 'turnos-calendario.html'
        }),
        __metadata("design:paramtypes", [NavController,
            TurnosProvider,
            AgendasProvider,
            NavParams,
            AuthProvider,
            PacienteProvider,
            ToastProvider,
            AlertController,
            ErrorReporterProvider,
            Platform])
    ], TurnosCalendarioPage);
    return TurnosCalendarioPage;
}());
export { TurnosCalendarioPage };
//# sourceMappingURL=turnos-calendario.js.map