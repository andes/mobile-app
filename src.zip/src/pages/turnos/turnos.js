var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, Platform, AlertController } from 'ionic-angular';
import * as moment from 'moment/moment';
import { TurnosProvider } from '../../providers/turnos';
import { DeviceProvider } from '../../providers/auth/device';
import { ErrorReporterProvider } from '../../providers/errorReporter';
// Components
import { TurnosDetallePage } from './detalles/turno-detalle';
import { TurnosPrestacionesPage } from './prestaciones/turnos-prestaciones';
var TurnosPage = (function () {
    function TurnosPage(navCtrl, navParams, turnosProvider, devices, alertCtrl, reporter, platform) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.turnosProvider = turnosProvider;
        this.devices = devices;
        this.alertCtrl = alertCtrl;
        this.reporter = reporter;
        this.platform = platform;
        this.selectOptions = {};
        this.turnos = null;
        this.habilitarTurnos = false;
        // this.getTurnos();
        this.onResumeSubscription = platform.resume.subscribe(function () {
            _this.getTurnos();
        });
        this.getTurnos();
    }
    TurnosPage.prototype.ngOnDestroy = function () {
        // always unsubscribe your subscriptions to prevent leaks
        this.onResumeSubscription.unsubscribe();
    };
    TurnosPage.prototype.ionViewDidLoad = function () {
        // this.getTurnos();
        this.reporter.alert();
    };
    TurnosPage.prototype.getTurnos = function () {
        var _this = this;
        var params = { horaInicio: moment(new Date()).format() };
        this.turnosProvider.get(params).then(function (data) {
            _this.turnos = data;
            _this.habilitarTurnos = true;
        }).catch(function () {
            // console.log('Error en la api');
        });
    };
    TurnosPage.prototype.onCancelTurno = function ($event) {
        this.turnos = this.turnos.filter(function (item) { return item._id !== $event._id; });
    };
    TurnosPage.prototype.onClickEvent = function ($event) {
        this.navCtrl.push(TurnosDetallePage, { turno: $event });
    };
    TurnosPage.prototype.buscarPrestacion = function () {
        this.navCtrl.push(TurnosPrestacionesPage, { turnos: this.turnos });
    };
    // terminar esta parte!
    TurnosPage.prototype.showConfirm = function (title, message) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var confirm = _this.alertCtrl.create({
                title: title,
                message: message,
                buttons: [
                    {
                        text: 'Cancelar',
                        handler: function () {
                            reject();
                        }
                    },
                    {
                        text: 'Aceptar',
                        handler: function () {
                            resolve();
                        }
                    }
                ]
            });
            confirm.present();
        });
    };
    TurnosPage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    TurnosPage = __decorate([
        Component({
            selector: 'page-turnos',
            templateUrl: 'turnos.html'
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            TurnosProvider,
            DeviceProvider,
            AlertController,
            ErrorReporterProvider,
            Platform])
    ], TurnosPage);
    return TurnosPage;
}());
export { TurnosPage };
//# sourceMappingURL=turnos.js.map