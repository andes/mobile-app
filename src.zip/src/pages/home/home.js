var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, MenuController } from 'ionic-angular';
import { AuthProvider } from '../../providers/auth/auth';
// pages
import { LoginPage } from '../login/login';
import { NumerosUtilesPage } from '../datos-utiles/numeros-emergencia/numeros-utiles';
import { FarmaciasTurnoPage } from '../datos-utiles/farmacias-turno/farmacias-turno';
import { FeedNoticiasPage } from '../datos-utiles/feed-noticias/feed-noticias';
import { CentrosSaludPage } from '../datos-utiles/centros-salud/centros-salud';
import { TurnosPage } from '../turnos/turnos';
import { AgendasPage } from '../profesional/agendas/agendas';
import { FormTerapeuticoPage } from '../profesional/form-terapeutico/form-terapeutico';
import { VacunasPage } from '../vacunas/vacunas';
import { LaboratoriosPage } from '../laboratorios/laboratorios';
import { FaqPage } from '../datos-utiles/faq/faq';
import { HistoriaDeSaludPage } from '../historia-salud/historia-salud';
import { DeviceProvider } from '../../providers/auth/device';
import { RupConsultorioPage } from '../profesional/consultorio/rup-consultorio';
import { ScanDocumentoPage } from '../profesional/mpi/scan-documento/scan-documento';
import { ErrorReporterProvider } from '../../providers/errorReporter';
import { CampaniasListPage } from '../datos-utiles/campanias/campanias-list';
var HomePage = (function () {
    function HomePage(authService, deviceService, navCtrl, menuCtrl, reporter) {
        this.authService = authService;
        this.deviceService = deviceService;
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.reporter = reporter;
        this.started = false;
        this.showMpi = false;
        this.user = this.authService.user;
    }
    HomePage.prototype.ionViewWillEnter = function () {
        this.menuCtrl.enable(true);
    };
    HomePage.prototype.ionViewDidLoad = function () {
        var _this = this;
        setTimeout(function () {
            debugger;
            _this.started = true;
        }, 50);
    };
    HomePage.prototype.isLogin = function () {
        return this.authService.user != null;
    };
    HomePage.prototype.isPaciente = function () {
        return this.authService.user && this.authService.user.profesionalId == null;
    };
    HomePage.prototype.isProfesional = function () {
        return this.authService.user && this.authService.user.profesionalId != null;
    };
    HomePage.prototype.login = function () {
        if (!this.isLogin()) {
            this.navCtrl.push(LoginPage);
        }
        else {
            //   this.reporter.report();
        }
    };
    HomePage.prototype.rup = function () {
        this.navCtrl.push(RupConsultorioPage);
    };
    HomePage.prototype.numerosUtiles = function () {
        this.navCtrl.push(NumerosUtilesPage);
    };
    HomePage.prototype.vacunas = function () {
        if (this.isLogin()) {
            this.navCtrl.push(VacunasPage);
        }
    };
    HomePage.prototype.laboratorio = function () {
        if (this.isLogin()) {
            this.navCtrl.push(LaboratoriosPage);
        }
    };
    HomePage.prototype.campanias = function () {
        this.navCtrl.push(CampaniasListPage);
    };
    HomePage.prototype.farmacias = function () {
        this.navCtrl.push(FarmaciasTurnoPage);
    };
    HomePage.prototype.noticias = function () {
        this.navCtrl.push(FeedNoticiasPage);
    };
    HomePage.prototype.misTurnos = function () {
        if (this.isLogin()) {
            this.navCtrl.push(TurnosPage);
        }
    };
    HomePage.prototype.misAgendas = function () {
        // this.navCtrl.push(RupAdjuntarPage,  { id: '5a93fe29071906410e389279' }  );
        if (this.isLogin()) {
            this.navCtrl.push(AgendasPage);
        }
    };
    HomePage.prototype.mpi = function () {
        if (this.isLogin()) {
            this.navCtrl.push(ScanDocumentoPage);
        }
    };
    HomePage.prototype.centrosDeSalud = function () {
        this.navCtrl.push(CentrosSaludPage);
    };
    HomePage.prototype.faq = function () {
        this.navCtrl.push(FaqPage);
    };
    HomePage.prototype.historiaDeSalud = function () {
        if (this.isLogin()) {
            this.navCtrl.push(HistoriaDeSaludPage);
        }
    };
    HomePage.prototype.formularioTerapeutico = function () {
        this.navCtrl.push(FormTerapeuticoPage);
    };
    HomePage = __decorate([
        Component({
            selector: 'page-home',
            templateUrl: 'home.html'
        }),
        __metadata("design:paramtypes", [AuthProvider,
            DeviceProvider,
            NavController,
            MenuController,
            ErrorReporterProvider])
    ], HomePage);
    return HomePage;
}());
export { HomePage };
//# sourceMappingURL=home.js.map