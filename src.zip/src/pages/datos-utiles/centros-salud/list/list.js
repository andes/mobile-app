var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { LocationsProvider } from '../../../../providers/locations/locations';
import { GeoProvider } from '../../../../providers/geo-provider';
var ListPage = (function () {
    function ListPage(navCtrl, navParams, locations, gMaps) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.locations = locations;
        this.gMaps = gMaps;
        this.position = {};
    }
    ListPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.locations.getV2().subscribe(function (result) {
            _this.points = result.filter(function (unCentro) { return unCentro.showMapa === true; });
            if (_this.gMaps.actualPosition) {
                _this.applyHaversine({ lat: _this.gMaps.actualPosition.latitude, lng: _this.gMaps.actualPosition.longitude });
                _this.points = _this.points.slice(0, 5);
            }
            else {
                _this.gMaps.getGeolocation().then(function (position) {
                    _this.applyHaversine({ lat: position.coords.latitude, lng: position.coords.longitude });
                    _this.points = _this.points.slice(0, 5);
                });
            }
        });
    };
    ListPage.prototype.applyHaversine = function (userLocation) {
        for (var i = 0; i < this.points.length; i++) {
            var placeLocation = {
                lat: this.points[i].direccion.geoReferencia[0],
                lng: this.points[i].direccion.geoReferencia[1]
            };
            this.points[i].distance = this.gMaps.getDistanceBetweenPoints(userLocation, placeLocation, 'km').toFixed(2);
            this.points.sort(function (locationA, locationB) {
                return locationA.distance - locationB.distance;
            });
        }
    };
    ListPage.prototype.navigateTo = function (location) {
        window.open('geo:?q=' + location[0] + ',' + location[1]);
    };
    ListPage.prototype.toMap = function (centro) {
        this.navigateTo(centro.direccion.geoReferencia);
    };
    ListPage = __decorate([
        Component({
            selector: 'page-list',
            templateUrl: 'list.html',
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            LocationsProvider,
            GeoProvider])
    ], ListPage);
    return ListPage;
}());
export { ListPage };
//# sourceMappingURL=list.js.map