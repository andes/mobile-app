var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { NavController, NavParams, Platform, AlertController } from 'ionic-angular';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { LocationsProvider } from '../../../../providers/locations/locations';
import { GeoProvider } from '../../../../providers/geo-provider';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Device } from '@ionic-native/device';
// Pages
import { CentrosSaludPrestaciones } from '../centros-salud-prestaciones';
/**
 * Generated class for the MapPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
var MapPage = (function () {
    function MapPage(navCtrl, navParams, maps, platform, locations, diagnostic, device, alertCtrl) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.maps = maps;
        this.platform = platform;
        this.locations = locations;
        this.diagnostic = diagnostic;
        this.device = device;
        this.alertCtrl = alertCtrl;
        this.prestaciones = [];
        this.centrosShow = [];
        this.center = {
            latitude: -38.951625,
            longitude: -68.060341
        };
        this.myPosition = null;
        this.zoom = 14;
        this._locationsSubscriptions = null;
        this.centroSaludSeleccionado = this.navParams.get('centroSeleccionado');
    }
    MapPage.prototype.ngOnDestroy = function () {
        if (this._locationsSubscriptions) {
            this._locationsSubscriptions.unsubscribe();
        }
    };
    MapPage.prototype.onClickCentro = function (centro) {
        // this.center.latitude = centro.direccion.geoReferencia[0];
        // this.center.longitude = centro.direccion.geoReferencia[1];
        (centro.ofertaPrestacional) ? this.prestaciones = centro.ofertaPrestacional : this.prestaciones = [];
    };
    MapPage.prototype.toPrestaciones = function (centro) {
        this.navCtrl.push(CentrosSaludPrestaciones, { centroSalud: centro });
    };
    MapPage.prototype.navigateTo = function (longitud, latitud) {
        if (this.platform.is('ios')) {
            window.open('maps://?q=' + longitud + ',' + latitud, '_system');
        }
        if (this.platform.is('android')) {
            window.open('geo:?q=' + longitud + ',' + latitud);
        }
    };
    MapPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this._locationsSubscriptions = _this.locations.getV2().subscribe(function (centros) {
                _this.centrosShow = centros.filter(function (unCentro) { return unCentro.showMapa === true; });
            });
            if (_this.platform.is('cordova')) {
                _this.diagnostic.isLocationEnabled().then(function (available) {
                    if (!available) {
                        _this.requestGeofef();
                    }
                    else {
                        _this.geoPosicionarme();
                    }
                }, function (error) {
                    alert('The following error occurred: ' + error);
                });
            }
            else {
                _this.geoPosicionarme();
            }
        }).catch(function (error) {
            // console.log(error)
        });
    };
    MapPage.prototype.requestGeofef = function () {
        var _this = this;
        var alert = this.alertCtrl.create({
            title: 'Acceder a ubicación',
            subTitle: 'Para poder utilizar este servicio, deberá activar la ubicación en su dispositivo.',
            buttons: [{
                    text: 'Continuar',
                    handler: function () {
                        _this.diagnostic.switchToLocationSettings();
                        _this.diagnostic.registerLocationStateChangeHandler(function (state) {
                            _this.hayUbicacion(state);
                        });
                    }
                }]
        });
        alert.present();
    };
    MapPage.prototype.hayUbicacion = function (state) {
        if ((this.device.platform === 'Android' && state !== this.diagnostic.locationMode.LOCATION_OFF)
            || (this.device.platform === 'iOS') && (state === this.diagnostic.permissionStatus.GRANTED
                || state === this.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE)) {
            this.geoPosicionarme();
        }
    };
    MapPage.prototype.geoPosicionarme = function () {
        var _this = this;
        this.maps.getGeolocation().then(function (position) {
            _this.myPosition = position.coords;
            _this.maps.setActual(_this.myPosition);
            // Si me geolocaliza, centra el mapa donde estoy
            _this.center.latitude = _this.myPosition.latitude;
            _this.center.longitude = _this.myPosition.longitude;
            // }
        });
    };
    __decorate([
        ViewChild('infoWindow'),
        __metadata("design:type", ElementRef)
    ], MapPage.prototype, "infoWindow", void 0);
    MapPage = __decorate([
        Component({
            selector: 'page-map',
            templateUrl: 'map.html',
            styles: ["\n        agm-map {\n            height: 100%;\n            width: 100%;\n        }\n    "],
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            GeoProvider,
            Platform,
            LocationsProvider,
            Diagnostic,
            Device,
            AlertController])
    ], MapPage);
    return MapPage;
}());
export { MapPage };
//# sourceMappingURL=map.js.map