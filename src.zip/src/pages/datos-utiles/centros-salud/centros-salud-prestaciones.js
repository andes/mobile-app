var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';
import { Platform } from 'ionic-angular/platform/platform';
/**
 * Generated class for the MapPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
var CentrosSaludPrestaciones = (function () {
    function CentrosSaludPrestaciones(navParams, platform) {
        this.navParams = navParams;
        this.platform = platform;
        this.onResumeSubscription = platform.resume.subscribe();
    }
    CentrosSaludPrestaciones.prototype.ngOnDestroy = function () {
        // always unsubscribe your subscriptions to prevent leaks
        this.onResumeSubscription.unsubscribe();
    };
    CentrosSaludPrestaciones.prototype.ionViewDidLoad = function () {
        this.centro = this.navParams.get('centroSalud');
        if (this.centro && this.centro.ofertaPrestacional.length > 0) {
            this.prestaciones = this.centro.ofertaPrestacional;
        }
    };
    CentrosSaludPrestaciones.prototype.call = function (phone) {
        window.open('tel:' + phone);
    };
    CentrosSaludPrestaciones.prototype.navigateTo = function (longitud, latitud) {
        if (this.platform.is('ios')) {
            window.open('maps://?q=' + longitud + ',' + latitud, '_system');
        }
        if (this.platform.is('android')) {
            window.open('geo:?q=' + longitud + ',' + latitud);
        }
    };
    CentrosSaludPrestaciones = __decorate([
        Component({
            selector: 'centros-salud-prestaciones',
            templateUrl: 'centros-salud-prestaciones.html',
            styles: ['centros-salud-prestaciones.html'],
        }),
        __metadata("design:paramtypes", [NavParams,
            Platform])
    ], CentrosSaludPrestaciones);
    return CentrosSaludPrestaciones;
}());
export { CentrosSaludPrestaciones };
//# sourceMappingURL=centros-salud-prestaciones.js.map