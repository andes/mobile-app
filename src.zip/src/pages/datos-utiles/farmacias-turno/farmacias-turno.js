var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import * as moment from 'moment';
// pages
// providers
import { AuthProvider } from '../../../providers/auth/auth';
import { FarmaciasProvider } from '../../../providers/farmacias';
var FarmaciasTurnoPage = (function () {
    function FarmaciasTurnoPage(authService, navCtrl, farmaciasCtrl) {
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.farmaciasCtrl = farmaciasCtrl;
        this.localidades = [];
        this.farmacias = [];
        this.loading = false;
        this.getLocalidades();
    }
    FarmaciasTurnoPage.prototype.onSelectLocalidad = function () {
        var _this = this;
        this.turnos(this.localidadSelect);
        this.localidadName = this.localidades.find(function (item) { return item.localidadId === _this.localidadSelect; }).nombre;
    };
    FarmaciasTurnoPage.prototype.formatFecha = function (f) {
        return moment(f.fecha).format('DD/MM');
    };
    FarmaciasTurnoPage.prototype.toMap = function (farmacia) {
        window.open('geo:?q=' + farmacia.latitud + ',' + farmacia.longitud);
    };
    FarmaciasTurnoPage.prototype.call = function (farmacia) {
        window.open('tel:' + farmacia.telefono);
    };
    FarmaciasTurnoPage.prototype.turnos = function (localidad) {
        var _this = this;
        this.loading = true;
        var params = {
            localidad: localidad,
            desde: moment().format('YYYY-MM-DD'),
            hasta: moment().add(2, 'day').format('YYYY-MM-DD'),
        };
        if (moment().hour() < 8) {
            params.desde = moment().subtract(1, 'day').format('YYYY-MM-DD');
        }
        this.farmaciasCtrl.getTurnos(params).then(function (data) {
            _this.farmacias = data;
            _this.loading = false;
        });
    };
    FarmaciasTurnoPage.prototype.getLocalidades = function () {
        var _this = this;
        this.loading = true;
        this.farmaciasCtrl.getLocalidades().then(function (data) {
            _this.loading = false;
            _this.localidades = data;
            var l = _this.localidades.find(function (item) { return item.localidadId === 1; });
            if (l) {
                _this.localidadSelect = parseInt(l.localidadId, 10);
                _this.localidadName = l.nombre;
                _this.turnos(parseInt(l.localidadId, 10));
            }
        });
    };
    FarmaciasTurnoPage = __decorate([
        Component({
            selector: 'page-farmacias-turno',
            templateUrl: 'farmacias-turno.html'
        }),
        __metadata("design:paramtypes", [AuthProvider,
            NavController,
            FarmaciasProvider])
    ], FarmaciasTurnoPage);
    return FarmaciasTurnoPage;
}());
export { FarmaciasTurnoPage };
//# sourceMappingURL=farmacias-turno.js.map