var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import * as moment from 'moment';
import { Http } from '@angular/http';
// pages
// providers
var FeedNoticiasPage = (function () {
    function FeedNoticiasPage(http, navCtrl, platform) {
        var _this = this;
        this.http = http;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.noticias = [];
        this.loading = true;
        moment.locale('es');
        // '
        var url;
        if (this.platform.is('core')) {
            url = '/feed';
        }
        else {
            url = 'http://www.saludneuquen.gob.ar/feed/';
        }
        this.http.get(url)
            .map(function (res) { return res.text(); })
            .subscribe(function (data) {
            _this.loading = false;
            if (data) {
                var parser = new DOMParser();
                var xmlData = parser.parseFromString(data, 'application/xml');
                var items = xmlData.querySelectorAll('item');
                for (var index = 0; index < items.length; index++) {
                    var element = items[index];
                    var title = element.getElementsByTagName('title')[0].innerHTML;
                    var link = element.getElementsByTagName('link')[0].innerHTML;
                    var date = new Date(element.getElementsByTagName('pubDate')[0].innerHTML);
                    var description = element.getElementsByTagName('description')[0].textContent;
                    var category = element.getElementsByTagName('category')[0].textContent;
                    var div = document.createElement('div');
                    div.innerHTML = description;
                    description = div.textContent || div.innerText || '';
                    var imgs = div.getElementsByTagName('img');
                    var img = null;
                    if (imgs.length > 0) {
                        img = imgs[0].getAttribute('src');
                    }
                    if (category !== 'Concursos') {
                        _this.noticias.push({ title: title, link: link, date: date, description: description, category: category, img: img });
                    }
                }
            }
            else {
            }
        });
    }
    FeedNoticiasPage.prototype.formatDate = function (noticia) {
        return moment(noticia.date).format('DD [de] MMMM [del] YYYY');
    };
    FeedNoticiasPage.prototype.openUrl = function (noticia) {
        window.open(noticia.link);
    };
    FeedNoticiasPage = __decorate([
        Component({
            selector: 'page-feed-noticias',
            templateUrl: 'feed-noticias.html'
        }),
        __metadata("design:paramtypes", [Http,
            NavController,
            Platform])
    ], FeedNoticiasPage);
    return FeedNoticiasPage;
}());
export { FeedNoticiasPage };
//# sourceMappingURL=feed-noticias.js.map