var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
// Pages
import { CampaniaDetallePage } from '../campanias/detalle/campania-detalle';
import * as moment from 'moment/moment';
// Providers
import { ErrorReporterProvider } from '../../../providers/errorReporter';
import { CampaniasProvider } from '../../../providers/campanias';
var CampaniasListPage = (function () {
    function CampaniasListPage(navCtrl, campaniasProvider, reporter) {
        this.navCtrl = navCtrl;
        this.campaniasProvider = campaniasProvider;
        this.reporter = reporter;
        this.campanias = [];
        this.getCampanias();
        moment.locale('es');
    }
    CampaniasListPage.prototype.ionViewDidLoad = function () {
    };
    CampaniasListPage.prototype.getCampanias = function () {
        var _this = this;
        this.campaniasProvider.get().then(function (data) {
            _this.campanias = data;
        }).catch((function (err) {
            // console.log('errorrrrr');
        }));
    };
    CampaniasListPage.prototype.periodo = function (campania) {
        return ('Desde el ' + moment(campania.vigencia.desde).format('DD [de] MMMM') + ' al ' + moment(campania.vigencia.hasta).format('DD [de] MMMM [del] YYYY'));
    };
    CampaniasListPage.prototype.verCampania = function (campania) {
        this.navCtrl.push(CampaniaDetallePage, { campania: campania });
    };
    CampaniasListPage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    CampaniasListPage = __decorate([
        Component({
            selector: 'page-campanias-list',
            templateUrl: 'campanias-list.html'
        }),
        __metadata("design:paramtypes", [NavController,
            CampaniasProvider,
            ErrorReporterProvider])
    ], CampaniasListPage);
    return CampaniasListPage;
}());
export { CampaniasListPage };
//# sourceMappingURL=campanias-list.js.map