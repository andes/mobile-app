var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { ErrorReporterProvider } from '../../../../providers/errorReporter';
import { DomSanitizer } from '@angular/platform-browser';
var CampaniaDetallePage = (function () {
    function CampaniaDetallePage(sanitizer, navCtrl, navParams, iab, reporter) {
        this.sanitizer = sanitizer;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.iab = iab;
        this.reporter = reporter;
        this.campania = this.navParams.get('campania');
    }
    CampaniaDetallePage.prototype.ionViewDidLoad = function () {
        this.imagen = this.sanitizer.bypassSecurityTrustHtml(this.campania.imagen);
    };
    CampaniaDetallePage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    CampaniaDetallePage.prototype.navigateTo = function (link) {
        var browser = this.iab.create(link);
    };
    CampaniaDetallePage = __decorate([
        Component({
            selector: 'page-campania-detalle',
            templateUrl: 'campania-detalle.html'
        }),
        __metadata("design:paramtypes", [DomSanitizer,
            NavController,
            NavParams,
            InAppBrowser,
            ErrorReporterProvider])
    ], CampaniaDetallePage);
    return CampaniaDetallePage;
}());
export { CampaniaDetallePage };
//# sourceMappingURL=campania-detalle.js.map