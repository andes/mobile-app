var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import * as moment from 'moment';
import { NoticiasProvider } from '../../../providers/noticias';
var PuntoSaludablePage = (function () {
    function PuntoSaludablePage(noticiasProvider, navCtrl, platform) {
        this.noticiasProvider = noticiasProvider;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.noticias = [];
        this.loading = true;
    }
    PuntoSaludablePage.prototype.formatDate = function (noticia) {
        return moment(noticia.fecha).format('DD [de] MMMM [del] YYYY');
    };
    PuntoSaludablePage.prototype.openUrl = function (noticia) {
        if (noticia.urls.length) {
            window.open(noticia.urls[0]);
        }
    };
    PuntoSaludablePage.prototype.ngOnInit = function () {
        var _this = this;
        moment.locale('es');
        this.noticiasProvider.puntoSaludable({}).then(function (data) {
            _this.noticias = data;
            _this.loading = false;
        });
    };
    PuntoSaludablePage = __decorate([
        Component({
            selector: 'page-punto-saludable',
            templateUrl: 'punto-saludable.html'
        }),
        __metadata("design:paramtypes", [NoticiasProvider,
            NavController,
            Platform])
    ], PuntoSaludablePage);
    return PuntoSaludablePage;
}());
export { PuntoSaludablePage };
//# sourceMappingURL=punto-saludable.js.map