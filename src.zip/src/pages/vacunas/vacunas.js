var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { AuthProvider } from './../../providers/auth/auth';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { VacunasProvider } from '../../providers/vacunas/vacunas';
import { ToastProvider } from '../../providers/toast';
import { ErrorReporterProvider } from '../../providers/errorReporter';
/**
 * Generated class for the VacunasPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
var VacunasPage = (function () {
    function VacunasPage(storage, vacunasProvider, navCtrl, navParams, authProvider, toastCtrl, reporter) {
        this.storage = storage;
        this.vacunasProvider = vacunasProvider;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.authProvider = authProvider;
        this.toastCtrl = toastCtrl;
        this.reporter = reporter;
        this.vacunas = null;
        this.getVacunas();
    }
    VacunasPage.prototype.ionViewDidLoad = function () {
        this.reporter.alert();
    };
    VacunasPage.prototype.onBugReport = function () {
        this.reporter.report();
    };
    VacunasPage.prototype.getVacunas = function () {
        var _this = this;
        var params = { dni: this.authProvider.user.documento };
        this.vacunasProvider.getCount(params).then(function (cantidad) {
            _this.storage.get('cantidadVacunasLocal').then(function (cantidadVacunasLocal) {
                // buscamos si hay vacunas almacenadas
                _this.storage.get('vacunas').then(function (vacunasLocal) {
                    if (!vacunasLocal || cantidadVacunasLocal !== cantidad) {
                        if (!cantidadVacunasLocal || cantidadVacunasLocal !== cantidad) {
                            // almacenamos la cantidad de vacunas en el telefono
                            _this.storage.set('cantidadVacunasLocal', cantidad);
                        }
                        _this.vacunasProvider.get(params).then(function (data) {
                            _this.vacunas = data;
                            _this.storage.set('vacunas', data);
                        }).catch(function () {
                            _this.vacunas = [];
                        });
                    }
                    else {
                        _this.vacunas = vacunasLocal;
                    }
                }).catch(function () {
                    _this.vacunas = [];
                });
            });
        });
    };
    VacunasPage = __decorate([
        Component({
            selector: 'page-vacunas',
            templateUrl: 'vacunas.html',
        }),
        __metadata("design:paramtypes", [Storage,
            VacunasProvider,
            NavController,
            NavParams,
            AuthProvider,
            ToastProvider,
            ErrorReporterProvider])
    ], VacunasPage);
    return VacunasPage;
}());
export { VacunasPage };
//# sourceMappingURL=vacunas.js.map