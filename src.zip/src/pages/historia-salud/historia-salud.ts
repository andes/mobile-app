import { Component } from '@angular/core';

@Component({
    selector: 'historia-salud',
    templateUrl: 'historia-salud.html',
})

export class HistoriaDeSaludPage { }
