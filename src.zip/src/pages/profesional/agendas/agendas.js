var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';
import * as moment from 'moment/moment';
// providers
import { AgendasProvider } from '../../../providers/agendas';
import { AuthProvider } from '../../../providers/auth/auth';
import { AgendaDetallePage } from '../../../pages/profesional/agendas/agenda-detalle/agenda-detalle';
var AgendasPage = (function () {
    function AgendasPage(navCtrl, navParams, agendasProvider, authProvider, platform) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.agendasProvider = agendasProvider;
        this.authProvider = authProvider;
        this.platform = platform;
        this.agendas = null;
        this.onResumeSubscription = platform.resume.subscribe(function () {
            _this.getAgendas();
        });
        this.getAgendas();
    }
    AgendasPage.prototype.ngOnDestroy = function () {
        // always unsubscribe your subscriptions to prevent leaks
        this.onResumeSubscription.unsubscribe();
    };
    AgendasPage.prototype.getAgendas = function () {
        var _this = this;
        var data = {
            estados: ['publicada', 'disponible'],
            idProfesional: this.authProvider.user.profesionalId,
            fechaDesde: moment(new Date()).startOf('day').toISOString()
        };
        this.agendasProvider.get(data).then(function (_data) {
            _this.agendas = _data;
        });
    };
    AgendasPage.prototype.onCancelAgenda = function ($event) {
        // console.log('onCancelAgenda');
    };
    AgendasPage.prototype.verDetalle = function (agenda) {
        this.navCtrl.push(AgendaDetallePage, { agenda: agenda });
    };
    AgendasPage = __decorate([
        Component({
            selector: 'page-agendas',
            templateUrl: 'agendas.html'
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            AgendasProvider,
            AuthProvider,
            Platform])
    ], AgendasPage);
    return AgendasPage;
}());
export { AgendasPage };
//# sourceMappingURL=agendas.js.map