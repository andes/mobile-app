var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';
// providers
import { AgendasProvider } from '../../../../providers/agendas';
import { AuthProvider } from '../../../../providers/auth/auth';
var AgendaDetallePage = (function () {
    function AgendaDetallePage(navCtrl, navParams, agendasProvider, authProvider, platform) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.agendasProvider = agendasProvider;
        this.authProvider = authProvider;
        this.platform = platform;
        this.agenda = null;
        this.turnos = [];
        this.onResumeSubscription = platform.resume.subscribe(function () {
        });
        this.agenda = this.navParams.get('agenda');
        for (var _i = 0, _a = this.agenda.sobreturnos; _i < _a.length; _i++) {
            var sobreturno = _a[_i];
            sobreturno.esSobreturno = true;
            this.turnos.push(sobreturno);
        }
        for (var _b = 0, _c = this.agenda.bloques; _b < _c.length; _b++) {
            var bloque = _c[_b];
            for (var _d = 0, _e = bloque.turnos; _d < _e.length; _d++) {
                var turno = _e[_d];
                if (turno.estado === 'asignado') {
                    this.turnos.push(turno);
                }
            }
        }
        this.turnos = this.turnos.sort(function (a, b) {
            return a.horaInicio.localeCompare(b.horaInicio);
        });
    }
    AgendaDetallePage.prototype.ngOnDestroy = function () {
        this.onResumeSubscription.unsubscribe();
    };
    AgendaDetallePage = __decorate([
        Component({
            selector: 'page-agenda-detalle',
            templateUrl: 'agenda-detalle.html'
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            AgendasProvider,
            AuthProvider,
            Platform])
    ], AgendaDetallePage);
    return AgendaDetallePage;
}());
export { AgendaDetallePage };
//# sourceMappingURL=agenda-detalle.js.map