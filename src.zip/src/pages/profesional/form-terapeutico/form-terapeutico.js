var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { EspecialidadesFTProvider } from './../../../providers/especialidadesFT';
import { FormTerapeuticoDetallePage } from './form-terapeutico-detalle';
import { FormTerapeuticoArbolPage } from './form-terapeutico-arbol';
import { LoadingController, NavController, NavParams } from 'ionic-angular';
import { AuthProvider } from './../../../providers/auth/auth';
import { FormBuilder } from '@angular/forms';
import { Component } from '@angular/core';
import { Storage } from '@ionic/storage';
import { FtpProvider } from '../../../providers/ftp';
var FormTerapeuticoPage = (function () {
    function FormTerapeuticoPage(storage, authService, loadingCtrl, navCtrl, navParams, formBuilder, ftp, esp, authProvider) {
        this.storage = storage;
        this.authService = authService;
        this.loadingCtrl = loadingCtrl;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.formBuilder = formBuilder;
        this.ftp = ftp;
        this.esp = esp;
        this.authProvider = authProvider;
        this.disableArbol = false;
        this.mostrarMenu = false;
        this.especialidadSelected = '';
        this.carroSelected = null;
        this.nivelSelected = '';
        this.niveles = ['1', '2', '3', '4', '5', '6', '7', '8', '8 y Serv Rehab (HBR)', '8 (NEO)', '8 (UTI)'];
    }
    FormTerapeuticoPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.esp.get({}).then(function (dataEsp) {
            _this.especialidades = dataEsp;
        });
    };
    FormTerapeuticoPage.prototype.onSelectEspecialidad = function () {
        // console.log(this.especialidadSelected)
    };
    FormTerapeuticoPage.prototype.onSelectCarro = function () {
        // console.log(this.carroSelected);
    };
    FormTerapeuticoPage.prototype.onSelectComplejidad = function () {
        // console.log(this.nivelSelected);
    };
    FormTerapeuticoPage.prototype.onKeyPress = function ($event, tag) {
    };
    FormTerapeuticoPage.prototype.limpiarNivel = function () {
        this.nivelSelected = '';
    };
    FormTerapeuticoPage.prototype.limpiarEspecialidad = function () {
        this.especialidadSelected = '';
    };
    FormTerapeuticoPage.prototype.buscarMedicamentos = function (params) {
        var _this = this;
        this.filtrados = [];
        this.ftp.get(params).then(function (data) {
            _this.filtrados = data;
        });
    };
    FormTerapeuticoPage.prototype.onCancel = function () {
        this.filtrados = [];
    };
    FormTerapeuticoPage.prototype.itemSelected = function (filtrado) {
        var _this = this;
        var query = {
            padre: filtrado.idpadre
        };
        this.ftp.get(query).then(function (padres) {
            var params = {
                item: filtrado,
                padres: padres
            };
            _this.navCtrl.push(FormTerapeuticoDetallePage, params);
        });
    };
    FormTerapeuticoPage.prototype.buscar = function () {
        var params = {
            nombreMedicamento: this.nombre
        };
        if (this.especialidadSelected) {
            params['especialidad'] = this.especialidadSelected.descripcion;
        }
        if (this.carroSelected) {
            params['carro'] = this.carroSelected;
        }
        if (this.nivelSelected) {
            params['nivel'] = this.nivelSelected;
        }
        this.buscarMedicamentos(params);
    };
    FormTerapeuticoPage.prototype.volver = function () {
        this.filtrados = [];
    };
    FormTerapeuticoPage.prototype.arbol = function () {
        var _this = this;
        this.disableArbol = true;
        this.ftp.get({ tree: 1, root: 1 }).then(function (data) {
            var params = {
                indices: data,
                titulo: 'Árbol'
            };
            _this.navCtrl.push(FormTerapeuticoArbolPage, params);
            _this.disableArbol = false;
        });
    };
    FormTerapeuticoPage = __decorate([
        Component({
            selector: 'form-terapeutico',
            templateUrl: 'form-terapeutico.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            LoadingController,
            NavController,
            NavParams,
            FormBuilder,
            FtpProvider,
            EspecialidadesFTProvider,
            AuthProvider])
    ], FormTerapeuticoPage);
    return FormTerapeuticoPage;
}());
export { FormTerapeuticoPage };
//# sourceMappingURL=form-terapeutico.js.map