var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { NavController, NavParams } from 'ionic-angular';
import { Component, Input } from '@angular/core';
import { FtpProvider } from '../../../providers/ftp';
import { FormTerapeuticoDetallePage } from './form-terapeutico-detalle';
var ArbolItem = (function () {
    function ArbolItem(navCtrl, navParams, ftp) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.ftp = ftp;
    }
    ArbolItem.prototype.esHoja = function () {
        return !this.indice.arbol || this.indice.arbol.length === 0;
    };
    ArbolItem.prototype.ngOnInit = function () {
    };
    ArbolItem.prototype.buscarHijos = function () {
        var _this = this;
        this.ftp.get({ tree: 1, idpadre: this.indice._id }).then(function (data) {
            _this.hijos = data;
        });
    };
    ArbolItem.prototype.verDetalle = function () {
        var params = {
            item: this.indice,
            idpadres: this.padres
        };
        this.navCtrl.push(FormTerapeuticoDetallePage, params);
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], ArbolItem.prototype, "indice", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], ArbolItem.prototype, "deep", void 0);
    ArbolItem = __decorate([
        Component({
            selector: 'arbolItem',
            templateUrl: 'arbolItem.html',
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            FtpProvider])
    ], ArbolItem);
    return ArbolItem;
}());
export { ArbolItem };
//# sourceMappingURL=arbolItem.js.map