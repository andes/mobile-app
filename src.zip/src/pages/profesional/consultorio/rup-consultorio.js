var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';
// providers
import { AuthProvider } from '../../../providers/auth/auth';
import { RupProvider } from '../../../providers/rup';
import { ToastProvider } from '../../../providers/toast';
import { RupAdjuntarPage } from '../rup-adjuntar/rup-adjuntar';
var RupConsultorioPage = (function () {
    function RupConsultorioPage(navCtrl, navParams, rup, authProvider, platform, toast) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.rup = rup;
        this.authProvider = authProvider;
        this.platform = platform;
        this.toast = toast;
        this.onResumeSubscription = platform.resume.subscribe(function () {
            _this.buscarSolicitudes();
        });
        this.buscarSolicitudes();
    }
    RupConsultorioPage.prototype.ngOnDestroy = function () {
        this.onResumeSubscription.unsubscribe();
    };
    RupConsultorioPage.prototype.buscarSolicitudes = function () {
        var _this = this;
        this.rup.get({}).then(function (data) {
            if (data && data.length > 0) {
                var index_1 = _this.navCtrl.length() - 1;
                _this.navCtrl.push(RupAdjuntarPage, { id: data[0]._id }).then(function () {
                    _this.navCtrl.remove(index_1);
                });
            }
            _this.solicitudes = data;
        }).catch(function () {
            _this.solicitudes = [];
        });
    };
    RupConsultorioPage.prototype.onClick = function (solicitud) {
        this.navCtrl.push(RupAdjuntarPage, { id: solicitud._id });
    };
    RupConsultorioPage = __decorate([
        Component({
            selector: 'page-rup-consultorio',
            templateUrl: 'rup-consultorio.html'
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            RupProvider,
            AuthProvider,
            Platform,
            ToastProvider])
    ], RupConsultorioPage);
    return RupConsultorioPage;
}());
export { RupConsultorioPage };
//# sourceMappingURL=rup-consultorio.js.map