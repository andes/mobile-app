var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChildren, QueryList, NgZone } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';
import * as moment from 'moment/moment';
// providers
import { Camera } from '@ionic-native/camera';
import { ImageResizer } from '@ionic-native/image-resizer';
import { Base64 } from '@ionic-native/base64';
import { FileChooser } from '@ionic-native/file-chooser';
import { DomSanitizer } from '@angular/platform-browser';
import { AuthProvider } from '../../../providers/auth/auth';
import { RupProvider } from '../../../providers/rup';
import { FilePath } from '@ionic-native/file-path';
import { ToastProvider } from '../../../providers/toast';
var RupAdjuntarPage = (function () {
    function RupAdjuntarPage(navCtrl, navParams, rup, authProvider, platform, zone, toast, fileChooser, camera, imageResizer, base64, sanitizer, filePath) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.rup = rup;
        this.authProvider = authProvider;
        this.platform = platform;
        this.zone = zone;
        this.toast = toast;
        this.fileChooser = fileChooser;
        this.camera = camera;
        this.imageResizer = imageResizer;
        this.base64 = base64;
        this.sanitizer = sanitizer;
        this.filePath = filePath;
        this.id = null;
        this.inProgress = false;
        this.extension = ['png', 'bmp', 'jpg', 'jpeg', 'png', 'pdf'];
        this.files = [];
        this.uploading = false;
        this.onResumeSubscription = platform.resume.subscribe(function () {
        });
        this.inProgress = true;
        this.id = this.navParams.get('id');
        this.rup.get({ id: this.id }).then(function (data) {
            _this.inProgress = false;
            _this.adjunto = data[0];
            _this.adjunto.fecha = moment(_this.adjunto.fecha);
        }).catch(function () {
            _this.inProgress = false;
            _this.navCtrl.pop();
        });
    }
    RupAdjuntarPage.prototype.ngOnDestroy = function () {
        this.onResumeSubscription.unsubscribe();
    };
    RupAdjuntarPage.prototype.takePhoto = function () {
        var _this = this;
        var item;
        var destinationType = this.platform.is('ios') ? 1 : 2;
        var fileName = this.platform.is('ios') ? 'rup-adjuntos' : null;
        var options = {
            quality: 70,
            correctOrientation: true,
            destinationType: destinationType,
            targetWidth: 600,
            targetHeight: 600,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then(function (imageData) {
            item = {
                loading: true
            };
            _this.files.push(item);
            return imageData;
        }).then(function (filePath) {
            return _this.base64.encodeFile(filePath);
        }).then(function (base64File) {
            var img = _this.sanitizer.bypassSecurityTrustResourceUrl(base64File);
            item.ext = 'jpg';
            item.file = img;
            item.plain64 = base64File;
            item.loading = false;
            _this.files = _this.files.slice();
        });
    };
    RupAdjuntarPage.prototype.fileExtension = function (file) {
        return file.slice((file.lastIndexOf('.') - 1 >>> 0) + 2);
    };
    RupAdjuntarPage.prototype.changeListener = function ($event) {
        var _this = this;
        var file = $event.target;
        if (file) {
            var ext_1 = this.fileExtension(file.value);
            if (this.extension.indexOf(ext_1) >= 0) {
                this.getBase64(file.files[0]).then(function (base64File) {
                    _this.childsComponents.first.nativeElement.value = '';
                    var img;
                    if (ext_1 === 'pdf') {
                        img = base64File.replace('image/*', 'application/pdf');
                    }
                    else {
                        img = _this.sanitizer.bypassSecurityTrustResourceUrl(base64File);
                        base64File = img.changingThisBreaksApplicationSecurity;
                    }
                    _this.zone.run(function () {
                        _this.files.push({
                            ext: ext_1,
                            file: img,
                            plain64: base64File
                        });
                        _this.files = _this.files.slice();
                    });
                });
            }
            else {
                this.toast.danger('TIPO DE ARCHIVO INVALIDO');
            }
        }
    };
    RupAdjuntarPage.prototype.getBase64 = function (file) {
        return new Promise(function (resolve, reject) {
            var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function () { return resolve(reader.result); };
            reader.onerror = function (error) { return reject(error); };
        });
    };
    RupAdjuntarPage.prototype.uploadFile = function () {
        var _this = this;
        this.zone.run(function () {
            _this.uploading = true;
        });
        var valores = [];
        this.files.forEach(function (item) {
            var elem = {
                ext: item.ext,
                plain64: item.plain64
            };
            valores.push(elem);
        });
        this.rup.patch(this.adjunto._id, { valor: { documentos: valores }, estado: 'upload' }).then(function () {
            _this.navCtrl.pop();
            _this.uploading = false;
        }).catch(function () {
            _this.uploading = false;
        });
    };
    RupAdjuntarPage.prototype.remove = function (i) {
        this.files.splice(i, 1);
    };
    __decorate([
        ViewChildren('upload'),
        __metadata("design:type", QueryList)
    ], RupAdjuntarPage.prototype, "childsComponents", void 0);
    RupAdjuntarPage = __decorate([
        Component({
            selector: 'page-rup-adjuntar',
            templateUrl: 'rup-adjuntar.html'
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            RupProvider,
            AuthProvider,
            Platform,
            NgZone,
            ToastProvider,
            FileChooser,
            Camera,
            ImageResizer,
            Base64,
            DomSanitizer,
            FilePath])
    ], RupAdjuntarPage);
    return RupAdjuntarPage;
}());
export { RupAdjuntarPage };
//# sourceMappingURL=rup-adjuntar.js.map