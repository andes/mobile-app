var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
// providers
import { AuthProvider } from '../../../../providers/auth/auth';
import { ScanParser } from '../../../../providers/scan-parser';
import { RegistroPacientePage } from '../registro-paciente/registro-paciente';
import { ToastProvider } from '../../../../providers/toast';
var ScanDocumentoPage = (function () {
    function ScanDocumentoPage(storage, authService, barcodeScanner, navCtrl, scanParser, toastCtrl, navParams) {
        this.storage = storage;
        this.authService = authService;
        this.barcodeScanner = barcodeScanner;
        this.navCtrl = navCtrl;
        this.scanParser = scanParser;
        this.toastCtrl = toastCtrl;
        this.navParams = navParams;
        this.modelo = {};
        this.textoLibre = null;
    }
    ScanDocumentoPage.prototype.ngOnInit = function () {
    };
    ScanDocumentoPage.prototype.ionViewDidLoad = function () {
    };
    ScanDocumentoPage.prototype.scanner = function () {
        var _this = this;
        this.barcodeScanner.scan({
            preferFrontCamera: false,
            formats: 'QR_CODE,PDF_417',
            disableSuccessBeep: false,
            showTorchButton: true,
            torchOn: true,
            prompt: 'Poner el código de barra en la cámara',
            resultDisplayDuration: 500,
        }).then(function (barcodeData) {
            // let barcodeData = {text: '10523200219632599@BOTTA@MARIANO ANDRES@M@34934522@A@09/03/1990@27/09/2013'}
            var datos = _this.scanParser.scan(barcodeData.text);
            if (datos) {
                _this.navCtrl.push(RegistroPacientePage, { datos: datos, scan: barcodeData.text });
            }
            else {
                _this.toastCtrl.danger('Documento invalido');
            }
        }, function (err) {
        });
    };
    ScanDocumentoPage = __decorate([
        Component({
            selector: 'page-scan-documento',
            templateUrl: 'scan-documento.html',
        }),
        __metadata("design:paramtypes", [Storage,
            AuthProvider,
            BarcodeScanner,
            NavController,
            ScanParser,
            ToastProvider,
            NavParams])
    ], ScanDocumentoPage);
    return ScanDocumentoPage;
}());
export { ScanDocumentoPage };
//# sourceMappingURL=scan-documento.js.map