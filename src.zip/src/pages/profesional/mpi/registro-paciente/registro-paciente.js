var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { PacienteMPIService } from '../../../../providers/paciente-mpi';
import * as moment from 'moment';
import { ToastProvider } from '../../../../providers/toast';
var RegistroPacientePage = (function () {
    function RegistroPacientePage(storage, navCtrl, navParams, toastCtrl, mpiService) {
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.toastCtrl = toastCtrl;
        this.mpiService = mpiService;
        this.paciente = {};
        this.textoLibre = null;
        this.inProgress = true;
        this.saving = false;
    }
    RegistroPacientePage.prototype.ngOnInit = function () {
    };
    RegistroPacientePage.prototype.volver = function () {
        this.navCtrl.pop();
    };
    RegistroPacientePage.prototype.save = function () {
        var _this = this;
        this.saving = true;
        this.mpiService.save(this.paciente).then(function (status) {
            _this.saving = false;
            _this.navCtrl.pop();
            _this.toastCtrl.success('PACIENTE REGISTRADO CON EXITO');
        }).catch(function () {
            _this.toastCtrl.danger('ERROR AL GUARDAR');
            _this.saving = false;
        });
    };
    RegistroPacientePage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.inProgress = true;
        var datos = this.navParams.get('datos');
        var scan = this.navParams.get('scan');
        var search = {
            type: 'simplequery',
            apellido: datos.apellido.toString(),
            nombre: datos.nombre.toString(),
            documento: datos.documento.toString(),
            sexo: datos.sexo.toString(),
            escaneado: true
        };
        this.mpiService.get(search).then(function (resultado) {
            if (resultado.length) {
                _this.paciente = resultado[0];
                _this.mpiService.getById(_this.paciente.id).then(function (pacUpdate) {
                    if (pacUpdate) {
                        _this.paciente = pacUpdate;
                        _this.estado = _this.paciente.estado;
                        if (_this.paciente.estado === 'temporal') {
                            _this.paciente.estado = 'validado';
                            _this.paciente.scan = scan;
                            _this.paciente.nombre = datos.nombre.toUpperCase();
                            _this.paciente.apellido = datos.apellido.toUpperCase();
                            _this.paciente.fechaNacimiento = moment(datos.fechaNacimiento, 'DD/MM/YYYY');
                            _this.paciente.sexo = datos.sexo.toLowerCase();
                            _this.paciente.documento = datos.documento;
                        }
                    }
                    else {
                        _this.estado = 'nuevo';
                        _this.paciente = {
                            estado: 'validado',
                            scan: scan,
                            nombre: datos.nombre.toUpperCase(),
                            apellido: datos.apellido.toUpperCase(),
                            fechaNacimiento: moment(datos.fechaNacimiento, 'DD/MM/YYYY'),
                            sexo: datos.sexo.toLowerCase(),
                            documento: datos.documento
                        };
                    }
                    _this.inProgress = false;
                });
            }
            else {
                // No existe el paciente
                _this.estado = 'nuevo';
                _this.paciente = {
                    estado: 'validado',
                    scan: scan,
                    nombre: datos.nombre.toUpperCase(),
                    apellido: datos.apellido.toUpperCase(),
                    fechaNacimiento: moment(datos.fechaNacimiento, 'DD/MM/YYYY'),
                    sexo: datos.sexo.toLowerCase(),
                    genero: datos.sexo.toLowerCase(),
                    documento: datos.documento
                };
                _this.inProgress = false;
            }
        });
    };
    RegistroPacientePage = __decorate([
        Component({
            selector: 'page-registro-paciente',
            templateUrl: 'registro-paciente.html',
        }),
        __metadata("design:paramtypes", [Storage,
            NavController,
            NavParams,
            ToastProvider,
            PacienteMPIService])
    ], RegistroPacientePage);
    return RegistroPacientePage;
}());
export { RegistroPacientePage };
//# sourceMappingURL=registro-paciente.js.map