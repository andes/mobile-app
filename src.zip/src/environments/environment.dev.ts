export const ENV = {
    REMEMBER_SESSION: false,
    APP_VERSION: 3412,
    MAP_KEY: 'AIzaSyAqYUabuhvLRq3c7CYDH6aTu5NHIpTTFQ4',
    // API_URL: 'http://localhost:3002/api/',
    // API_URL: 'https://demo.andes.gob.ar/api/',
    // API_URL: 'https://test.andes.gob.ar/api/',
    API_URL: 'https://demo.andes.gob.ar/api/',
    // API_URL: 'http://10.1.192.199:3002/api/',
    API_MOBILE_URL: 'http://192.168.0.105:3000/',
    REPOSITORIO: 'org.andes.mobile'
};
