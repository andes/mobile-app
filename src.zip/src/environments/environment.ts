// Para el repositorio produccion
// export const ENV = {
//     REMEMBER_SESSION: false,
//     APP_VERSION: 34,
//     MAP_KEY: 'AIzaSyAqYUabuhvLRq3c7CYDH6aTu5NHIpTTFQ4',
//     API_URL: 'https://app.andes.gob.ar/api/',
//     REPOSITORIO: 'org.andes.mobile'
//    };

// Para el repositorio developer
export const ENV = {
    REMEMBER_SESSION: false,
    APP_VERSION: 346,
    MAP_KEY: 'AIzaSyAqYUabuhvLRq3c7CYDH6aTu5NHIpTTFQ4',
    // API_URL: 'https://demo.andes.gob.ar/api/',
    API_MOBILE_URL : 'http://10.1.192.230:3000',
    API_URL: 'http://10.1.192.157:3002/api/',
    // API_URL: 'http://localhost:3002/api/',
    REPOSITORIO: 'org.andesDev.mobile'
};
