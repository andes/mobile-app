export var ENV = {
    REMEMBER_SESSION: false,
    APP_VERSION: 346,
    MAP_KEY: 'AIzaSyAqYUabuhvLRq3c7CYDH6aTu5NHIpTTFQ4',
    // API_URL: 'http://localhost:3002/api/',
    // API_URL: 'https://demo.andes.gob.ar/api/',
    API_URL: 'http://10.1.192.157:3002/api/',
    // API_URL: 'http://192.168.0.109:3002/api/'
    // API_URL: 'http://10.1.192.199:3002/api/',
    REPOSITORIO: 'org.andes.mobile'
};
//# sourceMappingURL=environment.dev.js.map