var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Storage } from '@ionic/storage';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
// providers
import { NetworkProvider } from '../network';
var LocationsProvider = (function () {
    function LocationsProvider(storage, network) {
        this.storage = storage;
        this.network = network;
        this.centros = [];
        this.baseUrl = 'core/tm';
    }
    LocationsProvider.prototype.getV2 = function () {
        var _this = this;
        return new Observable(function (observer) {
            if (_this.centros.length <= 0) {
                // Desactivamos la cache
                // this.storage.get('centros-salud').then(centros => {
                //     if (centros) {
                //         this.centros = centros;
                //         observer.next(centros);
                //     }
                // });
                _this.network.get(_this.baseUrl + '/organizaciones').then(function (data) {
                    if (data) {
                        var centrosSalud = data;
                        var limit = data.length;
                        for (var i = 0; i <= limit; i++) {
                            if (centrosSalud[i] && centrosSalud[i].direccion && centrosSalud[i].direccion.geoReferencia) {
                                _this.centros.push(centrosSalud[i]);
                            }
                        }
                        observer.next(_this.centros);
                    }
                    else {
                        return [];
                    }
                    // this.set('centros-salud', this.centros);
                }).catch(function (error) {
                    return;
                });
            }
            else {
                observer.next(_this.centros);
            }
        });
    };
    LocationsProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [Storage,
            NetworkProvider])
    ], LocationsProvider);
    return LocationsProvider;
}());
export { LocationsProvider };
//# sourceMappingURL=locations.js.map