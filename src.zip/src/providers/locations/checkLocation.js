var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { AlertController, Platform } from 'ionic-angular';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Device } from '@ionic-native/device';
import { GeoProvider } from '../../providers/geo-provider';
var CheckerGpsProvider = (function () {
    function CheckerGpsProvider(alertCtrl, platform, diagnostic, device, gMaps) {
        this.alertCtrl = alertCtrl;
        this.platform = platform;
        this.diagnostic = diagnostic;
        this.device = device;
        this.gMaps = gMaps;
        this.myPosition = null;
    }
    CheckerGpsProvider.prototype.checkGPS = function () {
        var _this = this;
        if (this.platform.is('cordova')) {
            this.diagnostic.isLocationEnabled().then(function (available) {
                if (!available) {
                    _this.requestGeofef();
                }
                else {
                    _this.geoPosicionarme();
                }
            }, function (error) {
                alert('Ha ocurrido un error: ' + error);
            });
        }
        else {
            this.geoPosicionarme();
        }
    };
    ;
    CheckerGpsProvider.prototype.requestGeofef = function () {
        var _this = this;
        var alert = this.alertCtrl.create({
            title: 'Acceder a ubicación',
            subTitle: 'Para este acceder a este servicio, deberá activar su GPS.',
            buttons: [{
                    text: 'Continuar',
                    handler: function () {
                        _this.diagnostic.switchToLocationSettings();
                        _this.diagnostic.registerLocationStateChangeHandler(function (state) {
                            _this.hayUbicacion(state);
                        });
                    }
                }]
        });
        alert.present();
    };
    CheckerGpsProvider.prototype.hayUbicacion = function (state) {
        if ((this.device.platform === 'Android' && state !== this.diagnostic.locationMode.LOCATION_OFF)
            || (this.device.platform === 'iOS') && (state === this.diagnostic.permissionStatus.GRANTED
                || state === this.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE)) {
            this.geoPosicionarme();
        }
    };
    CheckerGpsProvider.prototype.geoPosicionarme = function () {
        var _this = this;
        this.geoSubcribe = this.gMaps.watchPosition().subscribe(function (position) {
            _this.gMaps.setActual(_this.myPosition);
            _this.myPosition = position.coords;
        });
    };
    CheckerGpsProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [AlertController,
            Platform,
            Diagnostic,
            Device,
            GeoProvider])
    ], CheckerGpsProvider);
    return CheckerGpsProvider;
}());
export { CheckerGpsProvider };
;
//# sourceMappingURL=checkLocation.js.map