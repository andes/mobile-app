var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
// providers
import { NetworkProvider } from './network';
var RupProvider = (function () {
    function RupProvider(network) {
        this.network = network;
        this.baseUrl = 'modules/mobileApp';
    }
    RupProvider.prototype.get = function (params) {
        return this.network.get(this.baseUrl + '/prestaciones-adjuntar', params);
    };
    RupProvider.prototype.patch = function (id, data) {
        return this.network.patch(this.baseUrl + '/prestaciones-adjuntar/' + id, data);
    };
    RupProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [NetworkProvider])
    ], RupProvider);
    return RupProvider;
}());
export { RupProvider };
//# sourceMappingURL=rup.js.map