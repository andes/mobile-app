var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Storage } from '@ionic/storage';
// providers
import { NetworkProvider } from './../network';
import { JwtHelper } from 'angular2-jwt';
import * as shiroTrie from 'shiro-trie';
var AuthProvider = (function () {
    function AuthProvider(storage, network) {
        this.storage = storage;
        this.network = network;
        this.shiro = shiroTrie.newTrie();
        this.jwtHelper = new JwtHelper();
        this.authUrl = 'modules/mobileApp';
        this.authV2Url = 'modules/mobileApp/v2';
        this.appUrl = 'auth';
        this.user = null;
        this.token = null;
        this.permisos = [];
        this.recordame = false;
    }
    AuthProvider.prototype.getHeaders = function () {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        if (this.token) {
            headers.append('Authorization', 'JWT ' + this.token);
        }
        return headers;
    };
    AuthProvider.prototype.checkAuth = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.storage.get('token').then(function (token) {
                if (!token) {
                    return reject();
                }
                _this.storage.get('user').then(function (user) {
                    if (!user) {
                        return reject();
                    }
                    _this.token = token;
                    _this.user = user;
                    _this.permisos = _this.jwtHelper.decodeToken(token).permisos;
                    return resolve(user);
                });
            });
        });
    };
    AuthProvider.prototype.checkSession = function () {
        return this.storage.get('recordame');
    };
    AuthProvider.prototype._createAccount = function (details) {
        return this.network.post(this.authUrl + '/registro', details, {});
    };
    AuthProvider.prototype.updateAccount = function (details) {
        return this.network.patch(this.authUrl + '/account', details, {});
    };
    AuthProvider.prototype.login = function (credentials) {
        var _this = this;
        return this.network.post(this.authUrl + '/login', credentials, {}).then(function (data) {
            _this.token = data.token;
            _this.user = data.user;
            _this.storage.set('token', data.token);
            _this.storage.set('user', data.user);
            _this.permisos = _this.jwtHelper.decodeToken(data.token).permisos;
            _this.network.setToken(data.token);
            return Promise.resolve(data);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    AuthProvider.prototype.loginProfesional = function (credentials) {
        var _this = this;
        return this.network.post(this.appUrl + '/login', credentials, {}).then(function (data) {
            _this.token = data.token;
            _this.user = data.user;
            _this.storage.set('token', data.token);
            _this.storage.set('user', data.user);
            _this.storage.set('recordame', data.user.esGestion);
            _this.permisos = _this.jwtHelper.decodeToken(data.token).permisos;
            _this.network.setToken(data.token);
            return Promise.resolve(data);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    AuthProvider.prototype.selectOrganizacion = function (_data) {
        var _this = this;
        return this.network.post(this.appUrl + '/organizaciones', _data, {}).then(function (data) {
            _this.token = data.token;
            _this.storage.set('token', data.token);
            _this.network.setToken(data.token);
            _this.permisos = _this.jwtHelper.decodeToken(data.token).permisos;
            return Promise.resolve(data);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    AuthProvider.prototype.verificarCodigo = function (datos) {
        var _this = this;
        return this.network.post(this.authUrl + '/verificar-codigo', datos, {}).then(function (data) {
            _this.token = data.token;
            _this.user = data.user;
            _this.storage.set('token', data.token);
            _this.storage.set('user', data.user);
            _this.network.setToken(data.token);
            return Promise.resolve(data);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    AuthProvider.prototype.reenviarCodigo = function (emailEnviado) {
        var email = { 'email': emailEnviado };
        return this.network.post(this.authUrl + '/reenviar-codigo', email, {});
    };
    AuthProvider.prototype.logout = function () {
        this.storage.set('token', '');
        this.storage.set('user', '');
        this.storage.remove('cantidadVacunasLocal');
        this.storage.remove('vacunas');
        this.storage.remove('info-bug');
        this.token = null;
        this.user = null;
    };
    AuthProvider.prototype.update = function (params) {
        var _this = this;
        return this.network.put(this.authUrl + '/account', params, {}).then(function (data) {
            _this.user = data.account;
            return Promise.resolve(data);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    /**
     * Solo verificacmos que temos un código valido.
     * @param {string} email
     * @param {string} code
     */
    AuthProvider.prototype.checkCode = function (email, code) {
        return this.network.post(this.authV2Url + '/check', { email: email, code: code });
    };
    /**
     * Validamos los datos del scanneo y el código.
     * @param {string} email Email de la cuenta
     * @param {string} code Codigo de verificacion
     * @param {object} scan Datos del escaneo
     */
    AuthProvider.prototype.validarAccount = function (email, code, scan) {
        return this.network.post(this.authV2Url + '/verificar', { email: email, code: code, paciente: scan });
    };
    /**
     * Revalidamos todos los datos y creamos la cuenta
     * @param {string} email Email de la cuenta
     * @param {string} code Codigo de verificacion
     * @param {object} scan Datos del escaneo
     * @param {string} password Password a setear
     */
    AuthProvider.prototype.createAccount = function (email, code, scan, password) {
        var _this = this;
        return this.network.post(this.authV2Url + '/registrar', { email: email, code: code, password: password, paciente: scan }).then(function (data) {
            _this.token = data.token;
            _this.user = data.user;
            _this.storage.set('token', data.token);
            _this.storage.set('user', data.user);
            _this.network.setToken(data.token);
            return Promise.resolve(data);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    /**
     * Generar un codigo para reestablecer contraseña y luego
     * enviar un email con el codigo generado
     *
     * @param {string} email Email de la cuenta
     * @returns Promise
     * @memberof AuthProvider
     */
    AuthProvider.prototype.resetPassword = function (email) {
        return this.network.post(this.authUrl + '/olvide-password', { email: email }).then(function (res) {
            return Promise.resolve(res);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    /**
     * Resetear el password de un usuario
     *
     * @param {string} email Email del usuario al cambiar el password
     * @param {string} codigo Codigo de verificación enviado por email
     * @param {string} password Nuevo password
     * @param {string} password2 Re ingreso de nuevo password
     * @returns
     * @memberof AuthProvider
     */
    AuthProvider.prototype.restorePassword = function (email, codigo, password, password2) {
        var dto = {
            email: email,
            codigo: codigo,
            password: password,
            password2: password2
        };
        return this.network.post(this.authUrl + '/reestablecer-password', dto).then(function (res) {
            return Promise.resolve(res);
        }).catch(function (err) {
            return Promise.reject(err);
        });
    };
    /**
     * Busca actualizaciones de la app mobile
     * @param app_version
     */
    AuthProvider.prototype.checkVersion = function (app_version) {
        return this.network.post(this.authUrl + '/check-update', { app_version: app_version }, {}, { hideNoNetwork: true });
    };
    /**
     * Check de permisos con shiro para profesionales
     * @param permiso
     */
    AuthProvider.prototype.check = function (permiso) {
        this.shiro.reset();
        this.shiro.add(this.permisos);
        return this.shiro.permissions(permiso).length > 0;
    };
    AuthProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [Storage,
            NetworkProvider])
    ], AuthProvider);
    return AuthProvider;
}());
export { AuthProvider };
//# sourceMappingURL=auth.js.map