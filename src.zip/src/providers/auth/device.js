var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
import { Device } from '@ionic-native/device';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs/Observable';
// providers
import { NetworkProvider } from './../network';
import { ENV } from '@app/env';
import { RupAdjuntarPage } from '../../pages/profesional/rup-adjuntar/rup-adjuntar';
import { CampaniaDetallePage } from '../../pages/datos-utiles/campanias/detalle/campania-detalle';
var DeviceProvider = (function () {
    function DeviceProvider(device, storage, network) {
        var _this = this;
        this.device = device;
        this.storage = storage;
        this.network = network;
        this.registrationId = null;
        this.baseUrl = 'modules/mobileApp';
        this.navigateTo = null;
        this.storage.get('current_device').then(function (_device) {
            if (_device) {
                _this.currentDevice = _device;
            }
        });
    }
    /**
     * Register in push notifications server
     */
    DeviceProvider.prototype.init = function () {
        var _this = this;
        this.notification = new Observable(function (observer) {
            if (window.PushNotification) {
                var push = window.PushNotification.init({
                    android: {},
                    ios: {
                        alert: 'true',
                        badge: true,
                        sound: 'false'
                    },
                    windows: {}
                });
                push.on('registration', function (data) { return _this.onRegister(data); });
                push.on('notification', function (data) { return _this.onNotification(data, observer); });
                push.on('error', function (data) { return _this.onError(data); });
            }
        });
    };
    /**
     * Persist the registration ID
     * @param data
     */
    DeviceProvider.prototype.onRegister = function (data) {
        this.registrationId = data.registrationId;
        // console.log('Id de registrooooo: ', this.registrationId);
    };
    /**
     * Call when notification arrive
     * @param data
     */
    DeviceProvider.prototype.onNotification = function (data, observer) {
        if (data.additionalData.action === 'rup-adjuntar') {
            observer.next({
                component: RupAdjuntarPage,
                extras: { id: data.additionalData.id }
            });
        }
        if (data.additionalData.action === 'campaniaSalud') {
            observer.next({
                component: CampaniaDetallePage,
                extras: { campania: data.additionalData.campania }
            });
        }
    };
    /**
     * Call on error
     * @param data
     */
    DeviceProvider.prototype.onError = function (data) {
        // console.log('Notification error', data);
    };
    DeviceProvider.prototype.register = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            if (!_this.device.cordova) {
                reject();
                return;
            }
            var params = {
                device_id: _this.registrationId,
                device_type: _this.device.platform + ' ' + _this.device.version,
                app_version: ENV.APP_VERSION
            };
            _this.network.post(_this.baseUrl + '/devices/register', params).then(function (data) {
                _this.currentDevice = data;
                _this.storage.set('current_device', _this.currentDevice);
                return resolve(_this.currentDevice);
            }, reject);
        });
    };
    DeviceProvider.prototype.update = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            if (!_this.device.cordova) {
                reject();
                return;
            }
            var device = {
                id: _this.currentDevice.id,
                device_id: _this.registrationId,
                device_type: _this.device.platform + ' ' + _this.device.version,
                app_version: ENV.APP_VERSION
            };
            _this.network.post(_this.baseUrl + '/devices/update', { device: device }).then(function (data) {
                _this.currentDevice = data;
                _this.storage.set('current_device', _this.currentDevice);
                return resolve(_this.currentDevice);
            }, reject);
        });
    };
    DeviceProvider.prototype.remove = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            if (!_this.device.cordova) {
                reject();
                return;
            }
            _this.network.post(_this.baseUrl + '/devices/delete', { id: _this.currentDevice.id }).then(function (data) {
                _this.currentDevice = data;
                _this.storage.set('current_device', _this.currentDevice);
                return resolve(_this.currentDevice);
            }, reject);
            _this.storage.remove('current_device');
            _this.currentDevice = null;
        });
    };
    DeviceProvider.prototype.sync = function () {
        if (ENV.REMEMBER_SESSION) {
            this.register().then(function () { return true; }, function () { return true; });
        }
        else {
            if (this.currentDevice) {
                this.update().then(function () { return true; }, function () { return true; });
            }
            else {
                this.register().then(function () { return true; }, function () { return true; });
            }
        }
    };
    DeviceProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [Device,
            Storage,
            NetworkProvider])
    ], DeviceProvider);
    return DeviceProvider;
}());
export { DeviceProvider };
//# sourceMappingURL=device.js.map