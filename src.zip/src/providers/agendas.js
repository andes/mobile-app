var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
// providers
import { NetworkProvider } from './network';
var AgendasProvider = (function () {
    function AgendasProvider(network) {
        this.network = network;
        this.baseUrl = 'modules/turnos';
        this.baseUrlMobile = 'modules/mobileApp';
    }
    AgendasProvider.prototype.get = function (params) {
        return this.network.get(this.baseUrl + '/agenda', params);
    };
    AgendasProvider.prototype.getById = function (id) {
        return this.network.get(this.baseUrl + '/agenda/' + id);
    };
    AgendasProvider.prototype.getAgendasDisponibles = function (params) {
        return this.network.get(this.baseUrlMobile + '/agendasDisponibles', params);
    };
    AgendasProvider.prototype.patch = function (id, params) {
        return this.network.patch(this.baseUrl + '/agenda/' + id, params, {});
    };
    AgendasProvider.prototype.save = function (turno, options) {
        if (options === void 0) { options = {}; }
        if (turno.idAgenda) {
            return this.network.patch(this.baseUrl + '/turno/' + turno.idTurno + '/bloque/' + turno.idBloque + '/agenda/' + turno.idAgenda, turno, options);
        }
    };
    AgendasProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [NetworkProvider])
    ], AgendasProvider);
    return AgendasProvider;
}());
export { AgendasProvider };
//# sourceMappingURL=agendas.js.map