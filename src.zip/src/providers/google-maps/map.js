// import { Geolocation } from 'ionic-native';
var Map = (function () {
    function Map(mapElement, pleaseConnect) {
        this.markers = [];
        this.directionsService = null;
        this.directionsDisplay = null;
        this.bounds = null;
        this.mapElement = mapElement;
        this.pleaseConnectElement = pleaseConnect;
        // this.panelElement = panelElement;
        var latLng = new google.maps.LatLng(-38.951625, -68.060341);
        var mapOptions = {
            center: latLng,
            zoom: 12,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        this.mapObject = new google.maps.Map(this.mapElement, mapOptions);
        this.enableMap();
        this.directionsService = new google.maps.DirectionsService();
        this.directionsDisplay = new google.maps.DirectionsRenderer();
        this.bounds = new google.maps.LatLngBounds();
    }
    Map.prototype.deleteAllMarkers = function () {
        var total = this.markers.length;
        for (var i = 0; i < total; i++) {
            this.markers[i].setMap(null);
        }
        this.markers = [];
    };
    Map.prototype.addMarker = function (location, options) {
        var _this = this;
        var latLng = new google.maps.LatLng(location.latitude, location.longitude);
        var marker = new google.maps.Marker({
            map: this.mapObject,
            animation: google.maps.Animation.DROP,
            position: latLng,
            title: location.title,
            icon: location.image,
            draggable: (options && options.draggable) ? true : false
        });
        if (marker.title) {
            var infoWindowContent = document.createElement('div');
            infoWindowContent.innerHTML = '<span style="color: grey; font-size:16px;font-weight: 900;">' + marker.title + '</span></br>' +
                '<span style="color: grey; font-size:12px;font-weight: 900;">' + location.address + '</span></br>' +
                '<a id="idRuta' + location.index + '">¿Cómo llegar?</a>';
            var infoWindow_1 = new google.maps.InfoWindow({
                content: infoWindowContent,
                maxWidth: 400
            });
            google.maps.event.addListenerOnce(infoWindow_1, 'domready', function () {
                document.getElementById('idRuta' + location.index).addEventListener('click', function () {
                    var pos = {
                        lat: marker.getPosition().lat(),
                        lng: marker.getPosition().lng()
                    };
                    if (_this.myLatLng) {
                        _this.showRoute(pos);
                    }
                });
            });
            if (location.centroSeleccionado) {
                infoWindow_1.open(this.mapObject, marker);
                marker.setAnimation(google.maps.Animation.BOUNCE);
            }
            else {
                marker.addListener('click', function () {
                    infoWindow_1.open(_this.mapObject, marker);
                });
            }
            if (marker.draggable) {
                google.maps.event.addListener(marker, 'dragend', function () {
                    // TODO: Return new lat lang
                });
            }
        }
        this.markers.push(marker);
        return marker;
    };
    Map.prototype.miPosicion = function (miPosicion) {
        this.myLatLng = { lat: parseFloat(miPosicion.coords.latitude), lng: parseFloat(miPosicion.coords.longitude) };
        return this.myLatLng;
    };
    Map.prototype.disableMap = function () {
        if (this.pleaseConnectElement) {
            this.pleaseConnectElement.style.display = 'block';
        }
    };
    Map.prototype.enableMap = function () {
        if (this.pleaseConnectElement) {
            this.pleaseConnectElement.style.display = 'none';
        }
    };
    Map.prototype.showRoute = function (position) {
        this.directionsDisplay.setMap(this.mapObject);
        // commented out: panel de indicaciones al pie del mapa
        // this.directionsDisplay.setPanel(this.panelElement);
        this.calculateRoute(position);
    };
    Map.prototype.calculateRoute = function (position) {
        var _this = this;
        this.bounds.extend(this.myLatLng);
        this.mapObject.fitBounds(this.bounds);
        this.directionsService.route({
            origin: new google.maps.LatLng(this.myLatLng.lat, this.myLatLng.lng),
            destination: new google.maps.LatLng(position.lat, position.lng),
            travelMode: google.maps.TravelMode.DRIVING
        }, function (response, status) {
            if (status === google.maps.DirectionsStatus.OK) {
                _this.directionsDisplay.setDirections(response);
            }
            else {
                alert('Could not display directions due to: ' + status);
            }
        });
    };
    return Map;
}());
export { Map };
//# sourceMappingURL=map.js.map