var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
// providers
import { NetworkProvider } from './network';
var PacienteMPIService = (function () {
    function PacienteMPIService(network) {
        this.network = network;
        this.pacienteUrl = 'core/mpi/pacientes'; // URL to web api
    }
    PacienteMPIService.prototype.get = function (params) {
        return this.network.get(this.pacienteUrl, params);
    };
    /**
     * Metodo getById. Trae un objeto paciente por su Id.
     * @param {String} id Busca por Id
     */
    PacienteMPIService.prototype.getById = function (id) {
        return this.network.get(this.pacienteUrl + '/' + id, {});
    };
    PacienteMPIService.prototype.save = function (paciente) {
        if (paciente.id) {
            return this.network.put(this.pacienteUrl + '/' + paciente.id, paciente);
        }
        else {
            return this.network.post(this.pacienteUrl, paciente);
        }
    };
    PacienteMPIService = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [NetworkProvider])
    ], PacienteMPIService);
    return PacienteMPIService;
}());
export { PacienteMPIService };
//# sourceMappingURL=paciente-mpi.js.map