var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation';
import { Platform } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
var GeoProvider = (function () {
    function GeoProvider(platform, geolocation) {
        this.platform = platform;
        this.geolocation = geolocation;
        this.actualPosition = null;
    }
    GeoProvider.prototype.getGeolocation = function () {
        return this.geolocation.getCurrentPosition();
    };
    GeoProvider.prototype.setActual = function (position) {
        this.actualPosition = position;
    };
    GeoProvider.prototype.watchPosition = function () {
        var _this = this;
        var options = {
            timeout: 50000
        };
        if (this.platform.is('cordova')) {
            return this.geolocation.watchPosition(options);
            // .do(location => {
            //     this.actualPosition = location.coords;
            // });
        }
        else {
            return new Observable(function (observer) {
                navigator.geolocation.watchPosition(function (location) {
                    _this.actualPosition = location.coords;
                    observer.next(location);
                });
            });
        }
    };
    GeoProvider.prototype.getDistanceBetweenPoints = function (start, end, units) {
        var earthRadius = {
            miles: 3958.8,
            km: 6371
        };
        var R = earthRadius[units || 'km'];
        var lat1 = start.lat;
        var lon1 = start.lng;
        var lat2 = end.lat;
        var lon2 = end.lng;
        var dLat = this.toRad((lat2 - lat1));
        var dLon = this.toRad((lon2 - lon1));
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
                Math.sin(dLon / 2) *
                Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c;
        return d;
    };
    GeoProvider.prototype.toRad = function (x) {
        return x * Math.PI / 180;
    };
    GeoProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [Platform,
            Geolocation])
    ], GeoProvider);
    return GeoProvider;
}());
export { GeoProvider };
//# sourceMappingURL=geo-provider.js.map