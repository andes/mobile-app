var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import * as moment from 'moment';
var DatosGestionProvider = (function () {
    function DatosGestionProvider() {
        // public properties
        this.db = null;
    }
    // public methods
    DatosGestionProvider.prototype.setDatabase = function (db) {
        if (this.db === null) {
            this.db = db;
        }
    };
    DatosGestionProvider.prototype.create = function (tupla) {
        var sql = 'INSERT INTO datosGestion(idEfector, rh, camas, consultas, guardia, egresos, updated) VALUES(?,?,?,?,?,?,?)';
        var updated = moment().format('YYYY-MM-DD HH:mm');
        console.log('updated ', updated);
        return this.db.executeSql(sql, [tupla.idEfector, tupla.rh, tupla.camas, tupla.consultas, tupla.guardia, tupla.egresos, updated]);
    };
    DatosGestionProvider.prototype.createTable = function () {
        var sql = 'CREATE TABLE IF NOT EXISTS datosGestion(idEfector INTEGER, rh INTEGER, camas INTEGER, consultas INTEGER, guardia INTEGER, egresos INTEGER, updated DATETIME)';
        return this.db.executeSql(sql, []);
    };
    DatosGestionProvider.prototype.delete = function () {
        var sql = 'DROP TABLE datosGestion';
        return this.db.executeSql(sql, []);
    };
    DatosGestionProvider.prototype.obtenerDatos = function () {
        var sql = 'SELECT * FROM datosGestion';
        return this.db.executeSql(sql, [])
            .then(function (response) {
            var datos = [];
            for (var index = 0; index < response.rows.length; index++) {
                datos.push(response.rows.item(index));
            }
            return Promise.resolve(datos);
        })
            .catch(function (error) { return Promise.reject(error); });
    };
    DatosGestionProvider.prototype.update = function (task) {
        var sql = 'UPDATE datosGestion SET title=?, completed=? WHERE id=?';
        return this.db.executeSql(sql, [task.title, task.completed, task.id]);
    };
    DatosGestionProvider.prototype.borrarTabla = function () {
        var sql = 'DELETE FROM datosGestion';
        return this.db.executeSql(sql, []);
    };
    DatosGestionProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [])
    ], DatosGestionProvider);
    return DatosGestionProvider;
}());
export { DatosGestionProvider };
//# sourceMappingURL=datos-gestion.provider.js.map