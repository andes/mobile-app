var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { Screenshot } from '@ionic-native/screenshot';
import { EmailComposer } from '@ionic-native/email-composer';
import { AuthProvider } from './auth/auth';
import { AlertController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ToastProvider } from './toast';
var ErrorReporterProvider = (function () {
    function ErrorReporterProvider(emailCtr, screenshot, alertCtrl, storage, toastCtrl, auth) {
        this.emailCtr = emailCtr;
        this.screenshot = screenshot;
        this.alertCtrl = alertCtrl;
        this.storage = storage;
        this.toastCtrl = toastCtrl;
        this.auth = auth;
    }
    ErrorReporterProvider.prototype.makeInfo = function () {
        if (this.auth.user) {
            var texto = '';
            texto += 'Los siguientes son datos para identificar el usuario:<br/>';
            texto += 'Nombre: ' + this.auth.user.nombre + ' ' + this.auth.user.apellido;
            texto += '<br/>';
            texto += 'Documento: ' + this.auth.user.documento;
            texto += '<br/>';
            texto += 'A continuación escriba su mensaje: <br/> ';
            return texto;
        }
        else {
            return '';
        }
    };
    ErrorReporterProvider.prototype.makeAlert = function () {
        var alert = this.alertCtrl.create({
            title: 'Nueva funcionalidad',
            subTitle: 'En todas las pantallas informativas existe una opción, en la parte superior derecha, para denunciar datos incorrectos, notificar algún error de la aplicación o sugerir algún cambio.',
            buttons: ['Entiendo']
        });
        alert.present();
    };
    ErrorReporterProvider.prototype.alert = function () {
        var _this = this;
        this.storage.get('info-bug').then(function (present) {
            if (!present) {
                _this.makeAlert();
                _this.storage.set('info-bug', true);
            }
        });
    };
    ErrorReporterProvider.prototype.report = function () {
        var _this = this;
        this.screenshot.URI(80).then(function (data) {
            return _this.emailCtr.isAvailable().then(function (available) {
                var base64RegExp = /data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,(.*)/;
                var match = data.URI.match(base64RegExp);
                var email = {
                    to: 'info@andes.gob.ar',
                    attachments: [
                        'base64:screenshot.jpg//' + match[2]
                    ],
                    subject: 'ANDES - Error y/o segurencia',
                    body: _this.makeInfo(),
                    isHtml: true
                };
                _this.emailCtr.open(email);
            }).catch(function () {
                _this.toastCtrl.danger('CUENTA EMAIL NO CONFIGURADA');
            });
        }, function () {
            _this.toastCtrl.danger('CUENTA EMAIL NO CONFIGURADA');
        });
    };
    ErrorReporterProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [EmailComposer,
            Screenshot,
            AlertController,
            Storage,
            ToastProvider,
            AuthProvider])
    ], ErrorReporterProvider);
    return ErrorReporterProvider;
}());
export { ErrorReporterProvider };
//# sourceMappingURL=errorReporter.js.map