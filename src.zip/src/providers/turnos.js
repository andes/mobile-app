var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
// providers
import { NetworkProvider } from './network';
var TurnosProvider = (function () {
    function TurnosProvider(network) {
        this.network = network;
        this.baseUrl = 'modules/mobileApp';
    }
    TurnosProvider.prototype.get = function (params) {
        return this.network.get(this.baseUrl + '/turnos', params);
    };
    TurnosProvider.prototype.getPrestacionesTurneables = function () {
        return this.network.get(this.baseUrl + '/prestaciones/turneables');
    };
    TurnosProvider.prototype.getUbicacionTurno = function (id) {
        return this.network.get(this.baseUrl + '/turnos/ubicacion/organizacion/' + id);
    };
    TurnosProvider.prototype.cancelarTurno = function (body) {
        return this.network.post(this.baseUrl + '/turnos/cancelar', body, {});
    };
    TurnosProvider.prototype.confirmarTurno = function (body) {
        return this.network.post(this.baseUrl + '/turnos/confirmar', body, {});
    };
    TurnosProvider.prototype.obtenerTurno = function (body) {
        return this.network.post(this.baseUrl + '/turnos/obtener', body, {});
    };
    TurnosProvider.prototype.confirmarAsistenciaTurno = function (body) {
        return this.network.post(this.baseUrl + '/turnos/asistencia', body, {});
    };
    TurnosProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [NetworkProvider])
    ], TurnosProvider);
    return TurnosProvider;
}());
export { TurnosProvider };
//# sourceMappingURL=turnos.js.map