var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
// providers
import { NetworkProvider } from './network';
var PacienteProvider = (function () {
    function PacienteProvider(network) {
        this.network = network;
        this.baseUrl = 'modules/mobileApp';
    }
    PacienteProvider.prototype.get = function (id) {
        var _this = this;
        return this.network.get(this.baseUrl + '/paciente/' + id, {}).then(function (paciente) {
            _this.paciente = paciente;
            return Promise.resolve(paciente);
        }).catch(function (err) { return Promise.reject(err); });
    };
    PacienteProvider.prototype.laboratorios = function (id, extras) {
        return this.network.get(this.baseUrl + '/laboratorios/' + id, extras);
    };
    PacienteProvider.prototype.update = function (id, data) {
        return this.network.put(this.baseUrl + '/paciente/' + id, data, {});
    };
    PacienteProvider.prototype.patch = function (id, data) {
        return this.network.patch(this.baseUrl + '/pacientes/' + id, data, {});
    };
    PacienteProvider.prototype.restablecerPassword = function (email, data) {
        var _this = this;
        return this.network.post(this.baseUrl + '/restablecer-password', data).then(function (paciente) {
            _this.paciente = paciente;
            return Promise.resolve(paciente);
        }).catch(function (err) { return Promise.reject(err); });
    };
    PacienteProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [NetworkProvider])
    ], PacienteProvider);
    return PacienteProvider;
}());
export { PacienteProvider };
//# sourceMappingURL=paciente.js.map